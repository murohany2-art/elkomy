using DentalClinicPro.Models;
using Microsoft.EntityFrameworkCore;

namespace DentalClinicPro.Data;

/// <summary>
/// Entity Framework Core database context (SQLite).
/// Configures relationships, foreign keys and indexes for all entities.
/// </summary>
public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<Doctor> Doctors => Set<Doctor>();
    public DbSet<Patient> Patients => Set<Patient>();
    public DbSet<ToothRecord> ToothRecords => Set<ToothRecord>();
    public DbSet<Service> Services => Set<Service>();
    public DbSet<Appointment> Appointments => Set<Appointment>();
    public DbSet<Invoice> Invoices => Set<Invoice>();
    public DbSet<InvoiceItem> InvoiceItems => Set<InvoiceItem>();
    public DbSet<InventoryItem> InventoryItems => Set<InventoryItem>();
    public DbSet<Transaction> Transactions => Set<Transaction>();
    public DbSet<AppSetting> Settings => Set<AppSetting>();
    public DbSet<License> Licenses => Set<License>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);

        // ---- Users ----
        b.Entity<User>().HasIndex(u => u.Username).IsUnique();
        b.Entity<User>().HasIndex(u => u.Role);

        // ---- Doctors ----
        b.Entity<Doctor>().HasIndex(d => d.Name);
        b.Entity<Doctor>().Property(d => d.CommissionRate).HasColumnType("decimal(5,2)");
        b.Entity<Doctor>().Property(d => d.Salary).HasColumnType("decimal(12,2)");

        // ---- Patients ----
        b.Entity<Patient>().HasIndex(p => p.FileNumber).IsUnique();
        b.Entity<Patient>().HasIndex(p => p.Name);
        b.Entity<Patient>().HasIndex(p => p.Phone);
        b.Entity<Patient>()
            .HasOne(p => p.Doctor)
            .WithMany(d => d.Patients)
            .HasForeignKey(p => p.DoctorId)
            .OnDelete(DeleteBehavior.SetNull);

        // ---- ToothRecords ----
        b.Entity<ToothRecord>().HasIndex(t => t.PatientId);
        b.Entity<ToothRecord>()
            .HasOne(t => t.Patient)
            .WithMany(p => p.ToothRecords)
            .HasForeignKey(t => t.PatientId)
            .OnDelete(DeleteBehavior.Cascade);

        // ---- Services ----
        b.Entity<Service>().HasIndex(s => s.Name);
        b.Entity<Service>().Property(s => s.Price).HasColumnType("decimal(12,2)");

        // ---- Appointments ----
        b.Entity<Appointment>().HasIndex(a => a.StartTime);
        b.Entity<Appointment>()
            .HasOne(a => a.Patient).WithMany(p => p.Appointments)
            .HasForeignKey(a => a.PatientId).OnDelete(DeleteBehavior.Cascade);
        b.Entity<Appointment>()
            .HasOne(a => a.Doctor).WithMany(d => d.Appointments)
            .HasForeignKey(a => a.DoctorId).OnDelete(DeleteBehavior.SetNull);
        b.Entity<Appointment>()
            .HasOne(a => a.Service).WithMany()
            .HasForeignKey(a => a.ServiceId).OnDelete(DeleteBehavior.SetNull);

        // ---- Invoices ----
        b.Entity<Invoice>().HasIndex(i => i.InvoiceNumber).IsUnique();
        b.Entity<Invoice>().HasIndex(i => i.CreatedAt);
        foreach (var p in new[] { "Subtotal", "Discount", "Tax", "Total", "Paid" })
            b.Entity<Invoice>().Property(p).HasColumnType("decimal(12,2)");
        b.Entity<Invoice>()
            .HasOne(i => i.Patient).WithMany(p => p.Invoices)
            .HasForeignKey(i => i.PatientId).OnDelete(DeleteBehavior.SetNull);
        b.Entity<Invoice>()
            .HasOne(i => i.Doctor).WithMany()
            .HasForeignKey(i => i.DoctorId).OnDelete(DeleteBehavior.SetNull);

        // ---- InvoiceItems ----
        b.Entity<InvoiceItem>().HasIndex(i => i.InvoiceId);
        b.Entity<InvoiceItem>().Property(i => i.UnitPrice).HasColumnType("decimal(12,2)");
        b.Entity<InvoiceItem>().Property(i => i.Total).HasColumnType("decimal(12,2)");
        b.Entity<InvoiceItem>()
            .HasOne(i => i.Invoice).WithMany(inv => inv.Items)
            .HasForeignKey(i => i.InvoiceId).OnDelete(DeleteBehavior.Cascade);

        // ---- Inventory ----
        b.Entity<InventoryItem>().HasIndex(i => i.Name);
        b.Entity<InventoryItem>().Property(i => i.UnitPrice).HasColumnType("decimal(12,2)");

        // ---- Transactions ----
        b.Entity<Transaction>().HasIndex(t => t.Type);
        b.Entity<Transaction>().HasIndex(t => t.CreatedAt);
        b.Entity<Transaction>().Property(t => t.Amount).HasColumnType("decimal(12,2)");

        // ---- Settings / License ----
        b.Entity<AppSetting>().HasIndex(s => s.Key).IsUnique();
        b.Entity<License>().HasIndex(l => l.SerialKey).IsUnique();

        // ---- Ignore computed properties ----
        b.Entity<Patient>().Ignore(p => p.Age);
        b.Entity<Invoice>().Ignore(i => i.Remaining);
        b.Entity<InventoryItem>().Ignore(i => i.IsLow);
    }
}
