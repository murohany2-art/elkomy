using DentalClinicPro.Models;
using DentalClinicPro.Services;
using Microsoft.EntityFrameworkCore;

namespace DentalClinicPro.Data;

/// <summary>
/// Ensures the database exists and populates it with default users and
/// realistic demo data on first run. Idempotent.
/// </summary>
public class DbSeeder
{
    private readonly AppDbContext _db;
    private readonly IEncryptionService _crypto;

    public DbSeeder(AppDbContext db, IEncryptionService crypto)
    {
        _db = db;
        _crypto = crypto;
    }

    public async Task SeedAsync()
    {
        await _db.Database.EnsureCreatedAsync();

        if (await _db.Users.AnyAsync())
            return; // already seeded

        // ---- Default users (one per role) ----
        var admin = BCrypt.Net.BCrypt.HashPassword("admin123");
        var common = BCrypt.Net.BCrypt.HashPassword("123456");
        _db.Users.AddRange(
            new User { Username = "admin", FullName = "مدير النظام", Role = "admin", PasswordHash = admin, Email = "admin@dentalpro.app" },
            new User { Username = "doctor", FullName = "د. محمد أحمد", Role = "doctor", PasswordHash = common },
            new User { Username = "reception", FullName = "موظف الاستقبال", Role = "reception", PasswordHash = common },
            new User { Username = "accountant", FullName = "المحاسب", Role = "accountant", PasswordHash = common },
            new User { Username = "assistant", FullName = "مساعد الطبيب", Role = "assistant", PasswordHash = common }
        );

        // ---- Doctors ----
        var doctors = new List<Doctor>
        {
            new() { Name = "د. محمد أحمد", Specialty = "تقويم الأسنان", Phone = "01000000001", CommissionRate = 20, Salary = 15000, Color = "#0EA5E9" },
            new() { Name = "د. سارة علي", Specialty = "جراحة الفم", Phone = "01000000002", CommissionRate = 25, Salary = 18000, Color = "#6366F1" },
            new() { Name = "د. خالد حسن", Specialty = "علاج الجذور", Phone = "01000000003", CommissionRate = 18, Salary = 14000, Color = "#14B8A6" },
        };
        _db.Doctors.AddRange(doctors);

        // ---- Services ----
        var services = new List<Service>
        {
            new() { Name = "كشف وتشخيص", Category = "فحص", Price = 150, DurationMinutes = 20 },
            new() { Name = "حشو عادي", Category = "حشوات", Price = 400, DurationMinutes = 45 },
            new() { Name = "حشو عصب", Category = "علاج الجذور", Price = 1200, DurationMinutes = 90 },
            new() { Name = "خلع ضرس", Category = "جراحة", Price = 300, DurationMinutes = 30 },
            new() { Name = "تنظيف وتلميع", Category = "وقاية", Price = 350, DurationMinutes = 40 },
            new() { Name = "تبييض الأسنان", Category = "تجميل", Price = 2500, DurationMinutes = 60 },
            new() { Name = "تركيب تاج", Category = "تركيبات", Price = 3000, DurationMinutes = 60 },
            new() { Name = "زراعة سن", Category = "زراعة", Price = 8000, DurationMinutes = 120 },
        };
        _db.Services.AddRange(services);
        await _db.SaveChangesAsync();

        // ---- Patients ----
        var names = new[] { "أحمد مصطفى", "فاطمة الزهراء", "يوسف كمال", "نور حسين", "عمر شريف", "مريم سعيد" };
        var jobs = new[] { "مهندس", "معلمة", "محاسب", "طبيبة", "طالب", "ربة منزل" };
        var patients = new List<Patient>();
        for (int i = 0; i < names.Length; i++)
        {
            patients.Add(new Patient
            {
                FileNumber = $"P-{(i + 1):0000}",
                Name = names[i],
                Gender = i % 2 == 0 ? "male" : "female",
                Phone = $"010{(11111111 * (i + 1)) % 100000000:00000000}",
                Occupation = jobs[i],
                BirthDate = new DateTime(1980 + i * 3, (i % 9) + 1, 10 + i),
                DoctorId = doctors[i % doctors.Count].Id,
                Status = "active",
            });
        }
        _db.Patients.AddRange(patients);
        await _db.SaveChangesAsync();

        // ---- Appointments ----
        var now = DateTime.Now;
        var statuses = new[] { "scheduled", "confirmed", "completed", "scheduled", "confirmed", "completed" };
        for (int i = 0; i < patients.Count; i++)
        {
            var start = new DateTime(now.Year, now.Month, now.Day, 9 + i, 0, 0);
            if (i > 2) start = start.AddDays(i - 2);
            _db.Appointments.Add(new Appointment
            {
                PatientId = patients[i].Id,
                DoctorId = doctors[i % doctors.Count].Id,
                ServiceId = services[i % services.Count].Id,
                StartTime = start,
                EndTime = start.AddMinutes(45),
                Status = statuses[i],
            });
        }

        // ---- Invoices ----
        int invNo = 1;
        for (int i = 0; i < patients.Count; i++)
        {
            var svc = services[i % services.Count];
            var subtotal = svc.Price;
            var tax = Math.Round(subtotal * 0.14m, 2);
            var total = subtotal + tax;
            var paid = i % 3 == 0 ? total : i % 3 == 1 ? total / 2 : 0;
            var invoice = new Invoice
            {
                InvoiceNumber = $"INV-{invNo++:00000}",
                PatientId = patients[i].Id,
                DoctorId = doctors[i % doctors.Count].Id,
                Subtotal = subtotal,
                Tax = tax,
                Total = total,
                Paid = paid,
                PaymentMethod = new[] { "cash", "card", "transfer", "wallet" }[i % 4],
                Status = paid >= total ? "paid" : paid > 0 ? "partial" : "unpaid",
                CreatedAt = now.AddDays(-i * 2),
                Items = new List<InvoiceItem>
                {
                    new() { ServiceId = svc.Id, Description = svc.Name, Quantity = 1, UnitPrice = svc.Price, Total = svc.Price }
                }
            };
            _db.Invoices.Add(invoice);
        }

        // ---- Inventory ----
        _db.InventoryItems.AddRange(
            new InventoryItem { Name = "مخدر موضعي", Category = "medicine", Quantity = 40, MinQuantity = 10, UnitPrice = 25, Supplier = "الشركة الطبية", Barcode = "600100001" },
            new InventoryItem { Name = "مادة حشو ضوئي", Category = "material", Quantity = 8, MinQuantity = 10, UnitPrice = 300, Supplier = "دنتال سبلاي", Barcode = "600100002" },
            new InventoryItem { Name = "قفازات طبية", Category = "material", Quantity = 200, MinQuantity = 50, UnitPrice = 2, Supplier = "الشركة الطبية", Barcode = "600100003" },
            new InventoryItem { Name = "إبر تخدير", Category = "tool", Quantity = 5, MinQuantity = 20, UnitPrice = 5, Supplier = "دنتال سبلاي", Barcode = "600100004" }
        );

        // ---- Transactions ----
        _db.Transactions.AddRange(
            new Transaction { Type = "expense", Category = "إيجار", Amount = 8000, Description = "إيجار العيادة الشهري" },
            new Transaction { Type = "expense", Category = "مرتبات", Amount = 45000, Description = "رواتب الفريق" },
            new Transaction { Type = "expense", Category = "مستلزمات", Amount = 6000, Description = "شراء خامات" }
        );

        // ---- Settings ----
        _db.Settings.AddRange(
            new AppSetting { Key = "clinic_name", Value = "Dental Clinic Pro" },
            new AppSetting { Key = "clinic_phone", Value = "01284855036" },
            new AppSetting { Key = "clinic_address", Value = "القاهرة، مصر" },
            new AppSetting { Key = "currency", Value = "EGP" },
            new AppSetting { Key = "tax_rate", Value = "14" },
            new AppSetting { Key = "language", Value = "ar" }
        );

        await _db.SaveChangesAsync();
    }
}
