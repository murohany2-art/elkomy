using System.ComponentModel.DataAnnotations;

namespace DentalClinicPro.Models;

/// <summary>Key/value application setting persisted in the database.</summary>
public class AppSetting
{
    public int Id { get; set; }

    [Required, MaxLength(60)]
    public string Key { get; set; } = string.Empty;

    [MaxLength(1000)]
    public string? Value { get; set; }
}
