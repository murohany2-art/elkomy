using System.ComponentModel.DataAnnotations;

namespace DentalClinicPro.Models;

/// <summary>A scheduled appointment linking patient, doctor and service.</summary>
public class Appointment
{
    public int Id { get; set; }

    public int? PatientId { get; set; }
    public Patient? Patient { get; set; }

    public int? DoctorId { get; set; }
    public Doctor? Doctor { get; set; }

    public int? ServiceId { get; set; }
    public Service? Service { get; set; }

    public DateTime StartTime { get; set; }
    public DateTime? EndTime { get; set; }

    /// <summary>scheduled | confirmed | completed | cancelled | no_show.</summary>
    [Required, MaxLength(20)]
    public string Status { get; set; } = "scheduled";

    [MaxLength(1000)]
    public string? Notes { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;
}
