using System.ComponentModel.DataAnnotations;

namespace DentalClinicPro.Models;

/// <summary>Security audit trail entry.</summary>
public class AuditLog
{
    public int Id { get; set; }

    public int? UserId { get; set; }

    [MaxLength(60)]
    public string? Username { get; set; }

    [Required, MaxLength(60)]
    public string Action { get; set; } = string.Empty;

    [MaxLength(60)]
    public string? Entity { get; set; }

    [MaxLength(1000)]
    public string? Details { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;
}
