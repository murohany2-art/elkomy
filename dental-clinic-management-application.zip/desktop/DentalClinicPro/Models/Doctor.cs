using System.ComponentModel.DataAnnotations;

namespace DentalClinicPro.Models;

/// <summary>Clinic doctor / dentist.</summary>
public class Doctor
{
    public int Id { get; set; }

    [Required, MaxLength(120)]
    public string Name { get; set; } = string.Empty;

    [MaxLength(120)]
    public string? Specialty { get; set; }

    [MaxLength(30)]
    public string? Phone { get; set; }

    [MaxLength(120)]
    public string? Email { get; set; }

    /// <summary>Commission percentage on treatments.</summary>
    public decimal CommissionRate { get; set; }

    public decimal Salary { get; set; }

    [MaxLength(500)]
    public string? Schedule { get; set; }

    [MaxLength(300)]
    public string? PhotoPath { get; set; }

    /// <summary>Hex color used in the calendar.</summary>
    [MaxLength(9)]
    public string Color { get; set; } = "#0EA5E9";

    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public ICollection<Patient> Patients { get; set; } = new List<Patient>();
    public ICollection<Appointment> Appointments { get; set; } = new List<Appointment>();
}
