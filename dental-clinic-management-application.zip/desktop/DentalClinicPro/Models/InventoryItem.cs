using System.ComponentModel.DataAnnotations;

namespace DentalClinicPro.Models;

/// <summary>Stock item: medicine, material or tool.</summary>
public class InventoryItem
{
    public int Id { get; set; }

    [Required, MaxLength(120)]
    public string Name { get; set; } = string.Empty;

    /// <summary>medicine | material | tool.</summary>
    [MaxLength(30)]
    public string Category { get; set; } = "material";

    [MaxLength(60)]
    public string? Barcode { get; set; }

    public int Quantity { get; set; }
    public int MinQuantity { get; set; } = 5;
    public decimal UnitPrice { get; set; }

    [MaxLength(120)]
    public string? Supplier { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    /// <summary>True when stock is at or below its minimum threshold.</summary>
    public bool IsLow => Quantity <= MinQuantity;
}
