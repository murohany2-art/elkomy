using System.ComponentModel.DataAnnotations;

namespace DentalClinicPro.Models;

/// <summary>Patient invoice with line items and payment tracking.</summary>
public class Invoice
{
    public int Id { get; set; }

    [Required, MaxLength(30)]
    public string InvoiceNumber { get; set; } = string.Empty;

    public int? PatientId { get; set; }
    public Patient? Patient { get; set; }

    public int? DoctorId { get; set; }
    public Doctor? Doctor { get; set; }

    public decimal Subtotal { get; set; }
    public decimal Discount { get; set; }
    public decimal Tax { get; set; }
    public decimal Total { get; set; }
    public decimal Paid { get; set; }

    /// <summary>cash | card | transfer | wallet.</summary>
    [MaxLength(20)]
    public string PaymentMethod { get; set; } = "cash";

    /// <summary>paid | partial | unpaid.</summary>
    [MaxLength(20)]
    public string Status { get; set; } = "unpaid";

    [MaxLength(1000)]
    public string? Notes { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public ICollection<InvoiceItem> Items { get; set; } = new List<InvoiceItem>();

    public decimal Remaining => Total - Paid;
}
