using System.ComponentModel.DataAnnotations;

namespace DentalClinicPro.Models;

/// <summary>A single line on an invoice.</summary>
public class InvoiceItem
{
    public int Id { get; set; }

    public int InvoiceId { get; set; }
    public Invoice? Invoice { get; set; }

    public int? ServiceId { get; set; }
    public Service? Service { get; set; }

    [Required, MaxLength(200)]
    public string Description { get; set; } = string.Empty;

    public int Quantity { get; set; } = 1;
    public decimal UnitPrice { get; set; }
    public decimal Total { get; set; }
}
