using System.ComponentModel.DataAnnotations;

namespace DentalClinicPro.Models;

/// <summary>Software license / activation record (activation data is encrypted).</summary>
public class License
{
    public int Id { get; set; }

    [Required, MaxLength(40)]
    public string SerialKey { get; set; } = string.Empty;

    /// <summary>AES-256 encrypted activation payload.</summary>
    public string? ActivationData { get; set; }

    public bool IsActivated { get; set; }

    public DateTime? ActivatedAt { get; set; }
}
