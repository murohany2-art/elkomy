using System.ComponentModel.DataAnnotations;

namespace DentalClinicPro.Models;

/// <summary>Patient record including embedded medical file fields.</summary>
public class Patient
{
    public int Id { get; set; }

    [Required, MaxLength(30)]
    public string FileNumber { get; set; } = string.Empty;

    [Required, MaxLength(120)]
    public string Name { get; set; } = string.Empty;

    /// <summary>male | female.</summary>
    [MaxLength(10)]
    public string Gender { get; set; } = "male";

    public DateTime? BirthDate { get; set; }

    [MaxLength(30)]
    public string? Phone { get; set; }

    [MaxLength(250)]
    public string? Address { get; set; }

    [MaxLength(120)]
    public string? Email { get; set; }

    [MaxLength(120)]
    public string? Occupation { get; set; }

    [MaxLength(50)]
    public string? MaritalStatus { get; set; }

    [MaxLength(1000)]
    public string? Notes { get; set; }

    [MaxLength(300)]
    public string? PhotoPath { get; set; }

    /// <summary>active | inactive.</summary>
    [MaxLength(20)]
    public string Status { get; set; } = "active";

    public int? DoctorId { get; set; }
    public Doctor? Doctor { get; set; }

    // ---- Medical file ----
    [MaxLength(2000)] public string? MedicalHistory { get; set; }
    [MaxLength(1000)] public string? Medications { get; set; }
    [MaxLength(500)] public string? Allergies { get; set; }
    [MaxLength(500)] public string? ChronicDiseases { get; set; }
    [MaxLength(50)] public string? BloodPressure { get; set; }
    [MaxLength(50)] public string? BloodSugar { get; set; }
    [MaxLength(2000)] public string? TreatmentPlan { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public ICollection<ToothRecord> ToothRecords { get; set; } = new List<ToothRecord>();
    public ICollection<Appointment> Appointments { get; set; } = new List<Appointment>();
    public ICollection<Invoice> Invoices { get; set; } = new List<Invoice>();

    /// <summary>Computed age in years (not mapped).</summary>
    public int? Age => BirthDate.HasValue
        ? (int)((DateTime.Now - BirthDate.Value).TotalDays / 365.25)
        : null;
}
