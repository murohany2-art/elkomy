using System.ComponentModel.DataAnnotations;

namespace DentalClinicPro.Models;

/// <summary>Billable dental service / treatment.</summary>
public class Service
{
    public int Id { get; set; }

    [Required, MaxLength(120)]
    public string Name { get; set; } = string.Empty;

    [MaxLength(80)]
    public string? Category { get; set; }

    public decimal Price { get; set; }

    public int DurationMinutes { get; set; } = 30;

    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; } = DateTime.Now;
}
