using System.ComponentModel.DataAnnotations;

namespace DentalClinicPro.Models;

/// <summary>Odontogram entry: condition of a single tooth (FDI numbering).</summary>
public class ToothRecord
{
    public int Id { get; set; }

    public int PatientId { get; set; }
    public Patient? Patient { get; set; }

    /// <summary>FDI tooth number (11-48).</summary>
    public int ToothNumber { get; set; }

    /// <summary>
    /// healthy | extraction | filling | root_canal | prosthesis |
    /// implant | crown | cleaning | whitening | orthodontics.
    /// </summary>
    [Required, MaxLength(30)]
    public string Condition { get; set; } = "healthy";

    [MaxLength(500)]
    public string? Notes { get; set; }

    public DateTime UpdatedAt { get; set; } = DateTime.Now;
}
