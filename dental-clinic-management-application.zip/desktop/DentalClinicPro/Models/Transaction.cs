using System.ComponentModel.DataAnnotations;

namespace DentalClinicPro.Models;

/// <summary>Accounting entry (income or expense).</summary>
public class Transaction
{
    public int Id { get; set; }

    /// <summary>income | expense.</summary>
    [Required, MaxLength(20)]
    public string Type { get; set; } = "expense";

    [MaxLength(80)]
    public string? Category { get; set; }

    public decimal Amount { get; set; }

    [MaxLength(500)]
    public string? Description { get; set; }

    [MaxLength(120)]
    public string? Party { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;
}
