using System.ComponentModel.DataAnnotations;

namespace DentalClinicPro.Models;

/// <summary>System user with a role and hashed credentials.</summary>
public class User
{
    public int Id { get; set; }

    [Required, MaxLength(60)]
    public string Username { get; set; } = string.Empty;

    [Required, MaxLength(120)]
    public string FullName { get; set; } = string.Empty;

    /// <summary>BCrypt password hash.</summary>
    [Required]
    public string PasswordHash { get; set; } = string.Empty;

    /// <summary>admin | doctor | reception | accountant | assistant.</summary>
    [Required, MaxLength(30)]
    public string Role { get; set; } = "reception";

    [MaxLength(120)]
    public string? Email { get; set; }

    [MaxLength(30)]
    public string? Phone { get; set; }

    public bool IsActive { get; set; } = true;

    public DateTime? LastLoginAt { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;
}
