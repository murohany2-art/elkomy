using System.Linq.Expressions;
using DentalClinicPro.Data;
using Microsoft.EntityFrameworkCore;

namespace DentalClinicPro.Repositories;

/// <summary>Generic EF Core repository implementing common CRUD operations.</summary>
public class Repository<T> : IRepository<T> where T : class
{
    protected readonly AppDbContext Db;
    protected readonly DbSet<T> Set;

    public Repository(AppDbContext db)
    {
        Db = db;
        Set = db.Set<T>();
    }

    public IQueryable<T> Query() => Set.AsQueryable();

    public async Task<List<T>> GetAllAsync(Expression<Func<T, bool>>? predicate = null)
    {
        IQueryable<T> q = Set;
        if (predicate is not null) q = q.Where(predicate);
        return await q.ToListAsync();
    }

    public async Task<T?> GetByIdAsync(int id) => await Set.FindAsync(id);

    public async Task<T> AddAsync(T entity)
    {
        await Set.AddAsync(entity);
        await Db.SaveChangesAsync();
        return entity;
    }

    public async Task UpdateAsync(T entity)
    {
        Set.Update(entity);
        await Db.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        var entity = await Set.FindAsync(id);
        if (entity is not null)
        {
            Set.Remove(entity);
            await Db.SaveChangesAsync();
        }
    }

    public async Task<int> CountAsync(Expression<Func<T, bool>>? predicate = null)
    {
        IQueryable<T> q = Set;
        if (predicate is not null) q = q.Where(predicate);
        return await q.CountAsync();
    }
}
