using DentalClinicPro.Data;
using DentalClinicPro.Models;
using Microsoft.EntityFrameworkCore;

namespace DentalClinicPro.Services;

public class AuthService : IAuthService
{
    private readonly AppDbContext _db;

    public AuthService(AppDbContext db) => _db = db;

    public string HashPassword(string password) =>
        BCrypt.Net.BCrypt.HashPassword(password);

    public bool VerifyPassword(string password, string hash) =>
        BCrypt.Net.BCrypt.Verify(password, hash);

    public async Task<User?> LoginAsync(string username, string password)
    {
        var user = await _db.Users
            .FirstOrDefaultAsync(u => u.Username == username.Trim().ToLower() && u.IsActive);

        if (user is null || !VerifyPassword(password, user.PasswordHash))
            return null;

        user.LastLoginAt = DateTime.Now;
        _db.AuditLogs.Add(new AuditLog
        {
            UserId = user.Id,
            Username = user.Username,
            Action = "login",
            Entity = "auth"
        });
        await _db.SaveChangesAsync();
        return user;
    }
}
