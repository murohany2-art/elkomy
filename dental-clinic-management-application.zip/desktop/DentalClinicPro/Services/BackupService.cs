using System.IO;
using System.IO.Compression;

namespace DentalClinicPro.Services;

/// <summary>
/// Creates compressed + AES-encrypted backups of the SQLite database and
/// restores them. The database path is provided by the application host.
/// </summary>
public class BackupService : IBackupService
{
    private readonly IEncryptionService _crypto;
    private readonly string _dbPath;
    private readonly ILoggerService _logger;

    public BackupService(IEncryptionService crypto, string dbPath, ILoggerService logger)
    {
        _crypto = crypto;
        _dbPath = dbPath;
        _logger = logger;
    }

    public async Task<string> CreateBackupAsync(string destinationPath)
    {
        // 1) read db bytes, 2) gzip compress, 3) AES encrypt base64, 4) write file
        var raw = await File.ReadAllBytesAsync(_dbPath);

        using var ms = new MemoryStream();
        using (var gz = new GZipStream(ms, CompressionLevel.Optimal, leaveOpen: true))
            await gz.WriteAsync(raw);
        var compressed = Convert.ToBase64String(ms.ToArray());

        var encrypted = _crypto.Encrypt(compressed);
        await File.WriteAllTextAsync(destinationPath, encrypted);

        _logger.Info($"Backup created: {destinationPath} ({raw.Length} bytes)");
        return destinationPath;
    }

    public async Task RestoreBackupAsync(string backupPath)
    {
        var encrypted = await File.ReadAllTextAsync(backupPath);
        var compressed = _crypto.Decrypt(encrypted)
            ?? throw new InvalidOperationException("Invalid or corrupted backup file.");

        var bytes = Convert.FromBase64String(compressed);
        using var input = new MemoryStream(bytes);
        using var gz = new GZipStream(input, CompressionMode.Decompress);
        using var output = new MemoryStream();
        await gz.CopyToAsync(output);

        await File.WriteAllBytesAsync(_dbPath, output.ToArray());
        _logger.Info($"Backup restored from: {backupPath}");
    }
}
