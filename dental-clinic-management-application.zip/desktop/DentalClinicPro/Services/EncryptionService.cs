using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace DentalClinicPro.Services;

/// <summary>
/// AES-256-GCM encryption for license/backup data and an offline serial
/// generation/validation scheme (DCP-XXXX-XXXX-XXXX-CHECKSUM).
/// </summary>
public class EncryptionService : IEncryptionService
{
    private readonly byte[] _key;
    private readonly string _secret;

    public EncryptionService(string secret)
    {
        _secret = secret;
        _key = SHA256.HashData(Encoding.UTF8.GetBytes(secret));
    }

    public string Encrypt(string plainText)
    {
        var iv = RandomNumberGenerator.GetBytes(12);
        var plain = Encoding.UTF8.GetBytes(plainText);
        var cipher = new byte[plain.Length];
        var tag = new byte[16];
        using var aes = new AesGcm(_key, 16);
        aes.Encrypt(iv, plain, cipher, tag);
        return $"{Convert.ToBase64String(iv)}:{Convert.ToBase64String(tag)}:{Convert.ToBase64String(cipher)}";
    }

    public string? Decrypt(string cipherText)
    {
        try
        {
            var parts = cipherText.Split(':');
            if (parts.Length != 3) return null;
            var iv = Convert.FromBase64String(parts[0]);
            var tag = Convert.FromBase64String(parts[1]);
            var cipher = Convert.FromBase64String(parts[2]);
            var plain = new byte[cipher.Length];
            using var aes = new AesGcm(_key, 16);
            aes.Decrypt(iv, cipher, tag, plain);
            return Encoding.UTF8.GetString(plain);
        }
        catch
        {
            return null;
        }
    }

    private string Checksum(string basePart)
    {
        var hash = SHA256.HashData(Encoding.UTF8.GetBytes(basePart + _secret));
        return Convert.ToHexString(hash)[..4].ToUpperInvariant();
    }

    public string GenerateSerial()
    {
        string Block() => Convert.ToHexString(RandomNumberGenerator.GetBytes(2)).ToUpperInvariant();
        var a = Block(); var b = Block(); var c = Block();
        return $"DCP-{a}-{b}-{c}-{Checksum(a + b + c)}";
    }

    public bool ValidateSerial(string serial)
    {
        var m = Regex.Match(serial.Trim().ToUpperInvariant(),
            "^DCP-([0-9A-F]{4})-([0-9A-F]{4})-([0-9A-F]{4})-([0-9A-F]{4})$");
        if (!m.Success) return false;
        var basePart = m.Groups[1].Value + m.Groups[2].Value + m.Groups[3].Value;
        return Checksum(basePart) == m.Groups[4].Value;
    }
}
