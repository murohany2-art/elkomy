using DentalClinicPro.Models;

namespace DentalClinicPro.Services;

/// <summary>Authentication + password hashing.</summary>
public interface IAuthService
{
    Task<User?> LoginAsync(string username, string password);
    string HashPassword(string password);
    bool VerifyPassword(string password, string hash);
}
