namespace DentalClinicPro.Services;

/// <summary>Encrypted backup / restore of the SQLite database file.</summary>
public interface IBackupService
{
    /// <summary>Creates an encrypted backup at the given path; returns the file path.</summary>
    Task<string> CreateBackupAsync(string destinationPath);

    /// <summary>Restores an encrypted backup, overwriting the current database.</summary>
    Task RestoreBackupAsync(string backupPath);
}
