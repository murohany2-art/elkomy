namespace DentalClinicPro.Services;

/// <summary>Symmetric encryption + serial validation abstraction.</summary>
public interface IEncryptionService
{
    string Encrypt(string plainText);
    string? Decrypt(string cipherText);
    string GenerateSerial();
    bool ValidateSerial(string serial);
}
