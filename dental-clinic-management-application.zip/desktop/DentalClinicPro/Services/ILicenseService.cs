namespace DentalClinicPro.Services;

public enum ActivationResult { Success, InvalidSerial, AlreadyUsed }

/// <summary>Handles software activation persisted (encrypted) in the database.</summary>
public interface ILicenseService
{
    Task<bool> IsActivatedAsync();
    Task<ActivationResult> ActivateAsync(string serial);
    string GenerateDemoSerial();
}
