using System.ComponentModel;

namespace DentalClinicPro.Services;

/// <summary>
/// Runtime localization service. Raises change notifications so the whole UI
/// can switch between Arabic (RTL) and English (LTR) without restart.
/// </summary>
public interface ILocalizationService : INotifyPropertyChanged
{
    string CurrentLanguage { get; }
    bool IsRtl { get; }

    /// <summary>Translate a key for the current language.</summary>
    string this[string key] { get; }

    string Translate(string key);
    void SetLanguage(string language);
    event EventHandler? LanguageChanged;
}
