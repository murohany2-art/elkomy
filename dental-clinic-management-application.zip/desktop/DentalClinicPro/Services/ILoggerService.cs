namespace DentalClinicPro.Services;

/// <summary>Thin logging abstraction backed by Serilog.</summary>
public interface ILoggerService
{
    void Info(string message);
    void Warn(string message);
    void Error(string message, Exception? ex = null);
}
