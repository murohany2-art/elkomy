using DentalClinicPro.Models;

namespace DentalClinicPro.Services;

/// <summary>Holds the currently authenticated user for the app lifetime.</summary>
public interface ISessionService
{
    User? CurrentUser { get; set; }
    bool IsInRole(params string[] roles);
}
