using System.Text.Json;
using DentalClinicPro.Data;
using DentalClinicPro.Models;
using Microsoft.EntityFrameworkCore;

namespace DentalClinicPro.Services;

public class LicenseService : ILicenseService
{
    private readonly AppDbContext _db;
    private readonly IEncryptionService _crypto;

    public LicenseService(AppDbContext db, IEncryptionService crypto)
    {
        _db = db;
        _crypto = crypto;
    }

    public Task<bool> IsActivatedAsync() =>
        _db.Licenses.AnyAsync(l => l.IsActivated);

    public string GenerateDemoSerial() => _crypto.GenerateSerial();

    public async Task<ActivationResult> ActivateAsync(string serial)
    {
        var key = serial.Trim().ToUpperInvariant();
        if (!_crypto.ValidateSerial(key))
            return ActivationResult.InvalidSerial;

        var existing = await _db.Licenses.FirstOrDefaultAsync(l => l.SerialKey == key);
        if (existing?.IsActivated == true)
            return ActivationResult.AlreadyUsed;

        var payload = _crypto.Encrypt(JsonSerializer.Serialize(new
        {
            serial = key,
            activatedAt = DateTime.Now,
            machine = Environment.MachineName
        }));

        if (existing is null)
        {
            _db.Licenses.Add(new License
            {
                SerialKey = key,
                IsActivated = true,
                ActivationData = payload,
                ActivatedAt = DateTime.Now
            });
        }
        else
        {
            existing.IsActivated = true;
            existing.ActivationData = payload;
            existing.ActivatedAt = DateTime.Now;
        }

        await _db.SaveChangesAsync();
        return ActivationResult.Success;
    }
}
