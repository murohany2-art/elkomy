using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Threading;
using DentalClinicPro.Resources;

namespace DentalClinicPro.Services;

/// <summary>
/// Provides string translations and applies FlowDirection/Culture globally.
/// Views bind to it via the <c>Loc</c> markup extension / indexer.
/// </summary>
public class LocalizationService : ILocalizationService
{
    private string _language = "ar";

    public string CurrentLanguage => _language;
    public bool IsRtl => _language == "ar";

    public string this[string key] => Translate(key);

    public event PropertyChangedEventHandler? PropertyChanged;
    public event EventHandler? LanguageChanged;

    public string Translate(string key)
    {
        var dict = _language == "ar" ? Strings.Arabic : Strings.English;
        return dict.TryGetValue(key, out var value) ? value : key;
    }

    public void SetLanguage(string language)
    {
        if (_language == language) return;
        _language = language;

        var culture = new CultureInfo(language == "ar" ? "ar-EG" : "en-US");
        CultureInfo.CurrentCulture = culture;
        CultureInfo.CurrentUICulture = culture;

        // Apply flow direction to all open windows.
        var run = () =>
        {
            var dir = IsRtl ? FlowDirection.RightToLeft : FlowDirection.LeftToRight;
            foreach (Window w in Application.Current.Windows)
                w.FlowDirection = dir;
        };
        if (Application.Current?.Dispatcher.CheckAccess() == true) run();
        else Application.Current?.Dispatcher.Invoke(run);

        // Notify bindings: indexer uses the special "Item[]" property name.
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Item[]"));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsRtl)));
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CurrentLanguage)));
        LanguageChanged?.Invoke(this, EventArgs.Empty);
    }
}
