using Serilog;

namespace DentalClinicPro.Services;

/// <summary>Serilog-based file logger writing to %AppData%/DentalClinicPro/logs.</summary>
public class LoggerService : ILoggerService
{
    private readonly ILogger _log;

    public LoggerService()
    {
        var dir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "DentalClinicPro", "logs");
        Directory.CreateDirectory(dir);

        _log = new LoggerConfiguration()
            .WriteTo.File(
                Path.Combine(dir, "app-.log"),
                rollingInterval: RollingInterval.Day,
                retainedFileCountLimit: 30)
            .CreateLogger();
    }

    public void Info(string message) => _log.Information(message);
    public void Warn(string message) => _log.Warning(message);
    public void Error(string message, Exception? ex = null) => _log.Error(ex, message);
}
