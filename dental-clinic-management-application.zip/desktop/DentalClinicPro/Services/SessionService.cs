using DentalClinicPro.Models;

namespace DentalClinicPro.Services;

public class SessionService : ISessionService
{
    public User? CurrentUser { get; set; }

    public bool IsInRole(params string[] roles) =>
        CurrentUser is not null && roles.Contains(CurrentUser.Role);
}
