import { db } from "@/db";
import { appointments } from "@/db/schema";
import { eq } from "drizzle-orm";
import { handler, ok, requireUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export const PUT = handler(async (req, ctx) => {
  await requireUser();
  const id = Number((await ctx.params).id);
  const b = await req.json();
  const patch: Record<string, unknown> = {};
  if (b.status) patch.status = b.status;
  if (b.startTime) patch.startTime = new Date(b.startTime);
  if (b.endTime) patch.endTime = new Date(b.endTime);
  if (b.patientId !== undefined) patch.patientId = b.patientId ? Number(b.patientId) : null;
  if (b.doctorId !== undefined) patch.doctorId = b.doctorId ? Number(b.doctorId) : null;
  if (b.serviceId !== undefined) patch.serviceId = b.serviceId ? Number(b.serviceId) : null;
  if (b.notes !== undefined) patch.notes = b.notes || null;
  const [row] = await db.update(appointments).set(patch).where(eq(appointments.id, id)).returning();
  return ok(row);
});

export const DELETE = handler(async (_req, ctx) => {
  await requireUser();
  const id = Number((await ctx.params).id);
  await db.delete(appointments).where(eq(appointments.id, id));
  return ok({ success: true });
});
