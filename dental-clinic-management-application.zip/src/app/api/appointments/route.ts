import { db } from "@/db";
import { appointments, patients, doctors, services } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { handler, ok, requireUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export const GET = handler(async () => {
  await requireUser();
  const rows = await db
    .select({
      id: appointments.id,
      patientId: appointments.patientId,
      doctorId: appointments.doctorId,
      serviceId: appointments.serviceId,
      startTime: appointments.startTime,
      endTime: appointments.endTime,
      status: appointments.status,
      notes: appointments.notes,
      patientName: patients.name,
      doctorName: doctors.name,
      serviceName: services.name,
      doctorColor: doctors.color,
    })
    .from(appointments)
    .leftJoin(patients, eq(appointments.patientId, patients.id))
    .leftJoin(doctors, eq(appointments.doctorId, doctors.id))
    .leftJoin(services, eq(appointments.serviceId, services.id))
    .orderBy(desc(appointments.startTime));
  return ok(rows);
});

export const POST = handler(async (req) => {
  await requireUser();
  const b = await req.json();
  const start = new Date(b.startTime);
  const end = b.endTime ? new Date(b.endTime) : new Date(start.getTime() + 45 * 60000);
  const [row] = await db
    .insert(appointments)
    .values({
      patientId: b.patientId ? Number(b.patientId) : null,
      doctorId: b.doctorId ? Number(b.doctorId) : null,
      serviceId: b.serviceId ? Number(b.serviceId) : null,
      startTime: start,
      endTime: end,
      status: b.status || "scheduled",
      notes: b.notes || null,
    })
    .returning();
  return ok(row);
});
