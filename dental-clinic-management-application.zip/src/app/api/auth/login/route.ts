import { db } from "@/db";
import { users, auditLogs } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { verifyPassword, createSession } from "@/lib/auth";
import { handler, bad, ok } from "@/lib/api";

export const dynamic = "force-dynamic";

export const POST = handler(async (req) => {
  const { username, password, remember } = await req.json();
  if (!username || !password) return bad("missing_fields");

  const [user] = await db
    .select()
    .from(users)
    .where(eq(users.username, String(username).trim().toLowerCase()));

  if (!user || !user.isActive) return bad("invalid_credentials", 401);
  const okPass = await verifyPassword(password, user.passwordHash);
  if (!okPass) return bad("invalid_credentials", 401);

  await db
    .update(users)
    .set({ lastLoginAt: sql`now()` })
    .where(eq(users.id, user.id));

  await db.insert(auditLogs).values({
    userId: user.id,
    username: user.username,
    action: "login",
    entity: "auth",
  });

  await createSession(
    { id: user.id, username: user.username, fullName: user.fullName, role: user.role },
    Boolean(remember),
  );

  return ok({
    user: { id: user.id, username: user.username, fullName: user.fullName, role: user.role },
  });
});
