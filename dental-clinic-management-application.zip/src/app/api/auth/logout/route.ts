import { destroySession } from "@/lib/auth";
import { handler, ok } from "@/lib/api";

export const dynamic = "force-dynamic";

export const POST = handler(async () => {
  await destroySession();
  return ok({ success: true });
});
