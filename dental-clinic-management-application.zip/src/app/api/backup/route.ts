import { db } from "@/db";
import {
  patients,
  doctors,
  services,
  appointments,
  invoices,
  invoiceItems,
  inventory,
  transactions,
  toothRecords,
} from "@/db/schema";
import { handler, ok, requireUser } from "@/lib/api";
import { encrypt } from "@/lib/crypto";

export const dynamic = "force-dynamic";

/** Export an encrypted backup snapshot of core clinical data. */
export const GET = handler(async () => {
  await requireUser();
  const snapshot = {
    version: 1,
    createdAt: new Date().toISOString(),
    data: {
      patients: await db.select().from(patients),
      doctors: await db.select().from(doctors),
      services: await db.select().from(services),
      appointments: await db.select().from(appointments),
      invoices: await db.select().from(invoices),
      invoiceItems: await db.select().from(invoiceItems),
      inventory: await db.select().from(inventory),
      transactions: await db.select().from(transactions),
      toothRecords: await db.select().from(toothRecords),
    },
  };
  const encrypted = encrypt(JSON.stringify(snapshot));
  return ok({
    filename: `dental-backup-${new Date().toISOString().slice(0, 10)}.dcpbak`,
    encrypted,
    stats: Object.fromEntries(
      Object.entries(snapshot.data).map(([k, v]) => [k, (v as unknown[]).length]),
    ),
  });
});
