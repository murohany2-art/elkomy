import { db } from "@/db";
import {
  patients,
  doctors,
  appointments,
  invoices,
  inventory,
} from "@/db/schema";
import { sql, gte, and, lte, desc, eq } from "drizzle-orm";
import { handler, ok, requireUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export const GET = handler(async () => {
  await requireUser();

  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const endOfDay = new Date(startOfDay);
  endOfDay.setDate(endOfDay.getDate() + 1);
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  const num = (v: unknown) => Number(v ?? 0);

  const [pCount] = await db.select({ c: sql<number>`count(*)` }).from(patients);
  const [dCount] = await db.select({ c: sql<number>`count(*)` }).from(doctors);
  const [iCount] = await db.select({ c: sql<number>`count(*)` }).from(invoices);

  const [todayAppt] = await db
    .select({ c: sql<number>`count(*)` })
    .from(appointments)
    .where(and(gte(appointments.startTime, startOfDay), lte(appointments.startTime, endOfDay)));

  const [dailyRev] = await db
    .select({ s: sql<number>`coalesce(sum(${invoices.paid}),0)` })
    .from(invoices)
    .where(and(gte(invoices.createdAt, startOfDay), lte(invoices.createdAt, endOfDay)));

  const [monthlyRev] = await db
    .select({ s: sql<number>`coalesce(sum(${invoices.paid}),0)` })
    .from(invoices)
    .where(gte(invoices.createdAt, startOfMonth));

  const [totals] = await db
    .select({
      paid: sql<number>`coalesce(sum(${invoices.paid}),0)`,
      total: sql<number>`coalesce(sum(${invoices.total}),0)`,
    })
    .from(invoices);

  // Daily chart: last 7 days revenue
  const daily = await db
    .select({
      day: sql<string>`to_char(${invoices.createdAt},'YYYY-MM-DD')`,
      value: sql<number>`coalesce(sum(${invoices.paid}),0)`,
    })
    .from(invoices)
    .where(gte(invoices.createdAt, sql`now() - interval '6 days'`))
    .groupBy(sql`to_char(${invoices.createdAt},'YYYY-MM-DD')`);

  // Monthly chart: last 6 months
  const monthly = await db
    .select({
      month: sql<string>`to_char(${invoices.createdAt},'YYYY-MM')`,
      value: sql<number>`coalesce(sum(${invoices.paid}),0)`,
    })
    .from(invoices)
    .where(gte(invoices.createdAt, sql`now() - interval '5 months'`))
    .groupBy(sql`to_char(${invoices.createdAt},'YYYY-MM')`);

  const recentPatients = await db
    .select({ id: patients.id, name: patients.name, fileNumber: patients.fileNumber, createdAt: patients.createdAt })
    .from(patients)
    .orderBy(desc(patients.createdAt))
    .limit(5);

  const recentInvoices = await db
    .select({
      id: invoices.id,
      invoiceNumber: invoices.invoiceNumber,
      total: invoices.total,
      status: invoices.status,
      patientName: patients.name,
      createdAt: invoices.createdAt,
    })
    .from(invoices)
    .leftJoin(patients, eq(invoices.patientId, patients.id))
    .orderBy(desc(invoices.createdAt))
    .limit(5);

  const lowStock = await db
    .select({ id: inventory.id, name: inventory.name, quantity: inventory.quantity, minQuantity: inventory.minQuantity })
    .from(inventory)
    .where(sql`${inventory.quantity} <= ${inventory.minQuantity}`);

  return ok({
    totals: {
      patients: num(pCount?.c),
      doctors: num(dCount?.c),
      invoices: num(iCount?.c),
      todayAppointments: num(todayAppt?.c),
      dailyRevenue: num(dailyRev?.s),
      monthlyRevenue: num(monthlyRev?.s),
      paid: num(totals?.paid),
      outstanding: num(totals?.total) - num(totals?.paid),
    },
    daily,
    monthly,
    recentPatients,
    recentInvoices,
    lowStock,
  });
});
