import { db } from "@/db";
import { doctors } from "@/db/schema";
import { eq } from "drizzle-orm";
import { handler, ok, requireUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export const PUT = handler(async (req, ctx) => {
  await requireUser();
  const id = Number((await ctx.params).id);
  const b = await req.json();
  const [row] = await db
    .update(doctors)
    .set({
      name: b.name,
      specialty: b.specialty || null,
      phone: b.phone || null,
      email: b.email || null,
      commissionRate: b.commissionRate ? String(b.commissionRate) : "0",
      salary: b.salary ? String(b.salary) : "0",
      schedule: b.schedule || null,
      color: b.color || "#0ea5e9",
      isActive: b.isActive ?? true,
    })
    .where(eq(doctors.id, id))
    .returning();
  return ok(row);
});

export const DELETE = handler(async (_req, ctx) => {
  await requireUser();
  const id = Number((await ctx.params).id);
  await db.delete(doctors).where(eq(doctors.id, id));
  return ok({ success: true });
});
