import { db } from "@/db";
import { doctors } from "@/db/schema";
import { desc } from "drizzle-orm";
import { handler, ok, requireUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export const GET = handler(async () => {
  await requireUser();
  return ok(await db.select().from(doctors).orderBy(desc(doctors.createdAt)));
});

export const POST = handler(async (req) => {
  await requireUser();
  const b = await req.json();
  const [row] = await db
    .insert(doctors)
    .values({
      name: b.name,
      specialty: b.specialty || null,
      phone: b.phone || null,
      email: b.email || null,
      commissionRate: b.commissionRate ? String(b.commissionRate) : "0",
      salary: b.salary ? String(b.salary) : "0",
      schedule: b.schedule || null,
      color: b.color || "#0ea5e9",
      isActive: b.isActive ?? true,
    })
    .returning();
  return ok(row);
});
