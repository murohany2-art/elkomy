import { db } from "@/db";
import { inventory } from "@/db/schema";
import { eq } from "drizzle-orm";
import { handler, ok, requireUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export const PUT = handler(async (req, ctx) => {
  await requireUser();
  const id = Number((await ctx.params).id);
  const b = await req.json();
  const [row] = await db
    .update(inventory)
    .set({
      name: b.name,
      category: b.category || "material",
      barcode: b.barcode || null,
      quantity: Number(b.quantity || 0),
      minQuantity: Number(b.minQuantity || 5),
      unitPrice: b.unitPrice ? String(b.unitPrice) : "0",
      supplier: b.supplier || null,
    })
    .where(eq(inventory.id, id))
    .returning();
  return ok(row);
});

export const DELETE = handler(async (_req, ctx) => {
  await requireUser();
  const id = Number((await ctx.params).id);
  await db.delete(inventory).where(eq(inventory.id, id));
  return ok({ success: true });
});
