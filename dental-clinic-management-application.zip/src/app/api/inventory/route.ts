import { db } from "@/db";
import { inventory } from "@/db/schema";
import { desc } from "drizzle-orm";
import { handler, ok, requireUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export const GET = handler(async () => {
  await requireUser();
  return ok(await db.select().from(inventory).orderBy(desc(inventory.createdAt)));
});

export const POST = handler(async (req) => {
  await requireUser();
  const b = await req.json();
  const [row] = await db
    .insert(inventory)
    .values({
      name: b.name,
      category: b.category || "material",
      barcode: b.barcode || null,
      quantity: Number(b.quantity || 0),
      minQuantity: Number(b.minQuantity || 5),
      unitPrice: b.unitPrice ? String(b.unitPrice) : "0",
      supplier: b.supplier || null,
    })
    .returning();
  return ok(row);
});
