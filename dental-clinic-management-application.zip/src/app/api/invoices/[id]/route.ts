import { db } from "@/db";
import { invoices, invoiceItems, patients, doctors } from "@/db/schema";
import { eq } from "drizzle-orm";
import { handler, ok, bad, requireUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export const GET = handler(async (_req, ctx) => {
  await requireUser();
  const id = Number((await ctx.params).id);
  const [inv] = await db
    .select({
      id: invoices.id,
      invoiceNumber: invoices.invoiceNumber,
      patientName: patients.name,
      patientPhone: patients.phone,
      doctorName: doctors.name,
      subtotal: invoices.subtotal,
      discount: invoices.discount,
      tax: invoices.tax,
      total: invoices.total,
      paid: invoices.paid,
      paymentMethod: invoices.paymentMethod,
      status: invoices.status,
      notes: invoices.notes,
      createdAt: invoices.createdAt,
    })
    .from(invoices)
    .leftJoin(patients, eq(invoices.patientId, patients.id))
    .leftJoin(doctors, eq(invoices.doctorId, doctors.id))
    .where(eq(invoices.id, id));
  if (!inv) return bad("not_found", 404);
  const items = await db.select().from(invoiceItems).where(eq(invoiceItems.invoiceId, id));
  return ok({ ...inv, items });
});

export const PUT = handler(async (req, ctx) => {
  await requireUser();
  const id = Number((await ctx.params).id);
  const b = await req.json();
  const [inv] = await db.select().from(invoices).where(eq(invoices.id, id));
  if (!inv) return bad("not_found", 404);
  const total = Number(inv.total);
  const paid = Number(b.paid ?? inv.paid);
  const status = paid >= total && total > 0 ? "paid" : paid > 0 ? "partial" : "unpaid";
  const [row] = await db
    .update(invoices)
    .set({ paid: paid.toFixed(2), status, paymentMethod: b.paymentMethod ?? inv.paymentMethod })
    .where(eq(invoices.id, id))
    .returning();
  return ok(row);
});

export const DELETE = handler(async (_req, ctx) => {
  await requireUser();
  const id = Number((await ctx.params).id);
  await db.delete(invoices).where(eq(invoices.id, id));
  return ok({ success: true });
});
