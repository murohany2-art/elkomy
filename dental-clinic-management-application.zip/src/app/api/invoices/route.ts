import { db } from "@/db";
import { invoices, invoiceItems, patients, doctors } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { handler, ok, requireUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export const GET = handler(async () => {
  await requireUser();
  const rows = await db
    .select({
      id: invoices.id,
      invoiceNumber: invoices.invoiceNumber,
      patientId: invoices.patientId,
      patientName: patients.name,
      doctorName: doctors.name,
      subtotal: invoices.subtotal,
      discount: invoices.discount,
      tax: invoices.tax,
      total: invoices.total,
      paid: invoices.paid,
      paymentMethod: invoices.paymentMethod,
      status: invoices.status,
      createdAt: invoices.createdAt,
    })
    .from(invoices)
    .leftJoin(patients, eq(invoices.patientId, patients.id))
    .leftJoin(doctors, eq(invoices.doctorId, doctors.id))
    .orderBy(desc(invoices.createdAt));
  return ok(rows);
});

type Item = { serviceId?: number; description: string; quantity: number; unitPrice: number };

export const POST = handler(async (req) => {
  await requireUser();
  const b = await req.json();
  const items: Item[] = Array.isArray(b.items) ? b.items : [];
  const subtotal = items.reduce((s, it) => s + Number(it.unitPrice) * Number(it.quantity), 0);
  const discount = Number(b.discount || 0);
  const tax = Number(b.tax || 0);
  const total = subtotal - discount + tax;
  const paid = Number(b.paid || 0);
  const status = paid >= total && total > 0 ? "paid" : paid > 0 ? "partial" : "unpaid";

  const [c] = await db.select({ c: sql<number>`count(*)` }).from(invoices);
  const invoiceNumber = `INV-${String(Number(c?.c ?? 0) + 1).padStart(5, "0")}`;

  const [inv] = await db
    .insert(invoices)
    .values({
      invoiceNumber,
      patientId: b.patientId ? Number(b.patientId) : null,
      doctorId: b.doctorId ? Number(b.doctorId) : null,
      subtotal: subtotal.toFixed(2),
      discount: discount.toFixed(2),
      tax: tax.toFixed(2),
      total: total.toFixed(2),
      paid: paid.toFixed(2),
      paymentMethod: b.paymentMethod || "cash",
      status,
      notes: b.notes || null,
    })
    .returning();

  if (items.length) {
    await db.insert(invoiceItems).values(
      items.map((it) => ({
        invoiceId: inv.id,
        serviceId: it.serviceId ? Number(it.serviceId) : null,
        description: it.description,
        quantity: Number(it.quantity),
        unitPrice: Number(it.unitPrice).toFixed(2),
        total: (Number(it.unitPrice) * Number(it.quantity)).toFixed(2),
      })),
    );
  }
  return ok(inv);
});
