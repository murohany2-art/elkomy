import { db } from "@/db";
import { licenses } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { handler, ok, bad } from "@/lib/api";
import { validateSerial, generateSerial, encrypt } from "@/lib/crypto";

export const dynamic = "force-dynamic";

/** Returns activation status + a demo serial for convenience. */
export const GET = handler(async () => {
  const [row] = await db
    .select({ c: sql<number>`count(*)` })
    .from(licenses)
    .where(eq(licenses.isActivated, true));
  const activated = Number(row?.c ?? 0) > 0;
  return ok({ activated, demoSerial: generateSerial() });
});

/** Activate a serial. Validates format+checksum and prevents reuse. */
export const POST = handler(async (req) => {
  const { serial } = await req.json();
  if (!serial || !validateSerial(String(serial))) return bad("invalid_serial");

  const key = String(serial).trim().toUpperCase();
  const [existing] = await db
    .select()
    .from(licenses)
    .where(eq(licenses.serialKey, key));

  if (existing?.isActivated) return bad("serial_used", 409);

  const payload = encrypt(
    JSON.stringify({ serial: key, activatedAt: new Date().toISOString() }),
  );

  if (existing) {
    await db
      .update(licenses)
      .set({ isActivated: true, activationData: payload, activatedAt: sql`now()` })
      .where(eq(licenses.id, existing.id));
  } else {
    await db.insert(licenses).values({
      serialKey: key,
      isActivated: true,
      activationData: payload,
      activatedAt: sql`now()`,
    });
  }
  return ok({ success: true });
});
