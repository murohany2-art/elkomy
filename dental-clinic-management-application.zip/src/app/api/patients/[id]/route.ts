import { db } from "@/db";
import { patients } from "@/db/schema";
import { eq } from "drizzle-orm";
import { handler, ok, bad, requireUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export const GET = handler(async (_req, ctx) => {
  await requireUser();
  const id = Number((await ctx.params).id);
  const [row] = await db.select().from(patients).where(eq(patients.id, id));
  if (!row) return bad("not_found", 404);
  return ok(row);
});

export const PUT = handler(async (req, ctx) => {
  await requireUser();
  const id = Number((await ctx.params).id);
  const b = await req.json();
  const [row] = await db
    .update(patients)
    .set({
      name: b.name,
      gender: b.gender,
      birthDate: b.birthDate || null,
      phone: b.phone || null,
      address: b.address || null,
      email: b.email || null,
      occupation: b.occupation || null,
      maritalStatus: b.maritalStatus || null,
      notes: b.notes || null,
      status: b.status,
      doctorId: b.doctorId ? Number(b.doctorId) : null,
      medicalHistory: b.medicalHistory || null,
      medications: b.medications || null,
      allergies: b.allergies || null,
      chronicDiseases: b.chronicDiseases || null,
      bloodPressure: b.bloodPressure || null,
      bloodSugar: b.bloodSugar || null,
      treatmentPlan: b.treatmentPlan || null,
    })
    .where(eq(patients.id, id))
    .returning();
  if (!row) return bad("not_found", 404);
  return ok(row);
});

export const DELETE = handler(async (_req, ctx) => {
  await requireUser();
  const id = Number((await ctx.params).id);
  await db.delete(patients).where(eq(patients.id, id));
  return ok({ success: true });
});
