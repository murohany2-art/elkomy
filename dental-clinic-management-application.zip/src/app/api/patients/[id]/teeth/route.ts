import { db } from "@/db";
import { toothRecords } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { handler, ok, requireUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export const GET = handler(async (_req, ctx) => {
  await requireUser();
  const patientId = Number((await ctx.params).id);
  const rows = await db
    .select()
    .from(toothRecords)
    .where(eq(toothRecords.patientId, patientId));
  return ok(rows);
});

/** Upsert a single tooth condition. */
export const POST = handler(async (req, ctx) => {
  await requireUser();
  const patientId = Number((await ctx.params).id);
  const { toothNumber, condition, notes } = await req.json();
  const [existing] = await db
    .select()
    .from(toothRecords)
    .where(
      and(eq(toothRecords.patientId, patientId), eq(toothRecords.toothNumber, Number(toothNumber))),
    );
  if (existing) {
    const [row] = await db
      .update(toothRecords)
      .set({ condition, notes: notes || null, updatedAt: new Date() })
      .where(eq(toothRecords.id, existing.id))
      .returning();
    return ok(row);
  }
  const [row] = await db
    .insert(toothRecords)
    .values({ patientId, toothNumber: Number(toothNumber), condition, notes: notes || null })
    .returning();
  return ok(row);
});
