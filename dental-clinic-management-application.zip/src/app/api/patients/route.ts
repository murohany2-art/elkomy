import { db } from "@/db";
import { patients, doctors } from "@/db/schema";
import { desc, eq, ilike, or, sql } from "drizzle-orm";
import { handler, ok, requireUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export const GET = handler(async (req) => {
  await requireUser();
  const q = new URL(req.url).searchParams.get("q")?.trim();
  const where = q
    ? or(
        ilike(patients.name, `%${q}%`),
        ilike(patients.fileNumber, `%${q}%`),
        ilike(patients.phone, `%${q}%`),
      )
    : undefined;
  const rows = await db
    .select({
      id: patients.id,
      fileNumber: patients.fileNumber,
      name: patients.name,
      gender: patients.gender,
      birthDate: patients.birthDate,
      phone: patients.phone,
      email: patients.email,
      status: patients.status,
      doctorId: patients.doctorId,
      doctorName: doctors.name,
      createdAt: patients.createdAt,
    })
    .from(patients)
    .leftJoin(doctors, eq(patients.doctorId, doctors.id))
    .where(where)
    .orderBy(desc(patients.createdAt));
  return ok(rows);
});

export const POST = handler(async (req) => {
  await requireUser();
  const b = await req.json();
  let fileNumber = b.fileNumber?.trim();
  if (!fileNumber) {
    const [c] = await db.select({ c: sql<number>`count(*)` }).from(patients);
    fileNumber = `P-${String(Number(c?.c ?? 0) + 1).padStart(4, "0")}`;
  }
  const [row] = await db
    .insert(patients)
    .values({
      fileNumber,
      name: b.name,
      gender: b.gender || "male",
      birthDate: b.birthDate || null,
      phone: b.phone || null,
      address: b.address || null,
      email: b.email || null,
      occupation: b.occupation || null,
      maritalStatus: b.maritalStatus || null,
      notes: b.notes || null,
      status: b.status || "active",
      doctorId: b.doctorId ? Number(b.doctorId) : null,
      medicalHistory: b.medicalHistory || null,
      medications: b.medications || null,
      allergies: b.allergies || null,
      chronicDiseases: b.chronicDiseases || null,
      bloodPressure: b.bloodPressure || null,
      bloodSugar: b.bloodSugar || null,
      treatmentPlan: b.treatmentPlan || null,
    })
    .returning();
  return ok(row);
});
