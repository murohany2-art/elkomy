import { db } from "@/db";
import { invoices, invoiceItems, transactions, patients, doctors, services } from "@/db/schema";
import { sql, eq, desc } from "drizzle-orm";
import { handler, ok, requireUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export const GET = handler(async () => {
  await requireUser();
  const num = (v: unknown) => Number(v ?? 0);

  const [rev] = await db
    .select({ s: sql<number>`coalesce(sum(${invoices.paid}),0)` })
    .from(invoices);
  const [exp] = await db
    .select({ s: sql<number>`coalesce(sum(${transactions.amount}),0)` })
    .from(transactions)
    .where(eq(transactions.type, "expense"));

  const monthly = await db
    .select({
      month: sql<string>`to_char(${invoices.createdAt},'YYYY-MM')`,
      revenue: sql<number>`coalesce(sum(${invoices.paid}),0)`,
    })
    .from(invoices)
    .groupBy(sql`to_char(${invoices.createdAt},'YYYY-MM')`)
    .orderBy(sql`to_char(${invoices.createdAt},'YYYY-MM')`);

  const topServices = await db
    .select({
      name: services.name,
      count: sql<number>`count(*)`,
      revenue: sql<number>`coalesce(sum(${invoiceItems.total}),0)`,
    })
    .from(invoiceItems)
    .leftJoin(services, eq(invoiceItems.serviceId, services.id))
    .groupBy(services.name)
    .orderBy(desc(sql`coalesce(sum(${invoiceItems.total}),0)`))
    .limit(8);

  const byDoctor = await db
    .select({
      name: doctors.name,
      revenue: sql<number>`coalesce(sum(${invoices.paid}),0)`,
      count: sql<number>`count(${invoices.id})`,
    })
    .from(invoices)
    .leftJoin(doctors, eq(invoices.doctorId, doctors.id))
    .groupBy(doctors.name)
    .orderBy(desc(sql`coalesce(sum(${invoices.paid}),0)`));

  const [patientCount] = await db.select({ c: sql<number>`count(*)` }).from(patients);

  const revenue = num(rev?.s);
  const expenses = num(exp?.s);
  return ok({
    summary: { revenue, expenses, profit: revenue - expenses, patients: num(patientCount?.c) },
    monthly,
    topServices,
    byDoctor,
  });
});
