import { db } from "@/db";
import { services } from "@/db/schema";
import { desc } from "drizzle-orm";
import { handler, ok, requireUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export const GET = handler(async () => {
  await requireUser();
  return ok(await db.select().from(services).orderBy(desc(services.createdAt)));
});

export const POST = handler(async (req) => {
  await requireUser();
  const b = await req.json();
  const [row] = await db
    .insert(services)
    .values({
      name: b.name,
      category: b.category || null,
      price: b.price ? String(b.price) : "0",
      durationMinutes: b.durationMinutes ? Number(b.durationMinutes) : 30,
      isActive: b.isActive ?? true,
    })
    .returning();
  return ok(row);
});
