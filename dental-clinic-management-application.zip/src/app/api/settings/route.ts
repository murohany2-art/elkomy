import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { handler, ok, requireUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export const GET = handler(async () => {
  await requireUser();
  const rows = await db.select().from(settings);
  const map: Record<string, string> = {};
  for (const r of rows) map[r.key] = r.value ?? "";
  return ok(map);
});

export const PUT = handler(async (req) => {
  await requireUser();
  const b: Record<string, string> = await req.json();
  for (const [key, value] of Object.entries(b)) {
    await db
      .insert(settings)
      .values({ key, value: String(value) })
      .onConflictDoUpdate({ target: settings.key, set: { value: String(value) } });
  }
  await db.execute(sql`select 1`); // no-op keep import used
  return ok({ success: true });
});
