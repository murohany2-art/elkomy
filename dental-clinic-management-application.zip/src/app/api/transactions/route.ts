import { db } from "@/db";
import { transactions, invoices } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { handler, ok, requireUser } from "@/lib/api";

export const dynamic = "force-dynamic";

export const GET = handler(async () => {
  await requireUser();
  const rows = await db.select().from(transactions).orderBy(desc(transactions.createdAt));
  const [inc] = await db
    .select({ s: sql<number>`coalesce(sum(${transactions.amount}),0)` })
    .from(transactions)
    .where(eq(transactions.type, "income"));
  const [exp] = await db
    .select({ s: sql<number>`coalesce(sum(${transactions.amount}),0)` })
    .from(transactions)
    .where(eq(transactions.type, "expense"));
  const [rev] = await db
    .select({ s: sql<number>`coalesce(sum(${invoices.paid}),0)` })
    .from(invoices);
  const income = Number(inc?.s ?? 0) + Number(rev?.s ?? 0);
  const expenses = Number(exp?.s ?? 0);
  return ok({ rows, summary: { income, expenses, balance: income - expenses } });
});

export const POST = handler(async (req) => {
  await requireUser();
  const b = await req.json();
  const [row] = await db
    .insert(transactions)
    .values({
      type: b.type || "expense",
      category: b.category || null,
      amount: b.amount ? String(b.amount) : "0",
      description: b.description || null,
      party: b.party || null,
    })
    .returning();
  return ok(row);
});
