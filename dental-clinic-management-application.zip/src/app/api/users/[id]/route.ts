import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { handler, ok, bad, requireUser } from "@/lib/api";
import { hashPassword } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const PUT = handler(async (req, ctx) => {
  const me = await requireUser();
  if (me.role !== "admin") return bad("forbidden", 403);
  const id = Number((await ctx.params).id);
  const b = await req.json();
  const patch: Record<string, unknown> = {
    fullName: b.fullName,
    role: b.role,
    email: b.email || null,
    phone: b.phone || null,
    isActive: b.isActive ?? true,
  };
  if (b.password) patch.passwordHash = await hashPassword(b.password);
  const [row] = await db.update(users).set(patch).where(eq(users.id, id)).returning({ id: users.id });
  return ok(row);
});

export const DELETE = handler(async (_req, ctx) => {
  const me = await requireUser();
  if (me.role !== "admin") return bad("forbidden", 403);
  const id = Number((await ctx.params).id);
  if (id === me.id) return bad("cannot_delete_self", 400);
  await db.delete(users).where(eq(users.id, id));
  return ok({ success: true });
});
