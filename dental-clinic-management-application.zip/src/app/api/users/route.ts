import { db } from "@/db";
import { users } from "@/db/schema";
import { desc } from "drizzle-orm";
import { handler, ok, bad, requireUser } from "@/lib/api";
import { hashPassword } from "@/lib/auth";

export const dynamic = "force-dynamic";

export const GET = handler(async () => {
  const me = await requireUser();
  if (me.role !== "admin") return bad("forbidden", 403);
  const rows = await db
    .select({
      id: users.id,
      username: users.username,
      fullName: users.fullName,
      role: users.role,
      email: users.email,
      phone: users.phone,
      isActive: users.isActive,
      lastLoginAt: users.lastLoginAt,
    })
    .from(users)
    .orderBy(desc(users.createdAt));
  return ok(rows);
});

export const POST = handler(async (req) => {
  const me = await requireUser();
  if (me.role !== "admin") return bad("forbidden", 403);
  const b = await req.json();
  if (!b.username || !b.password) return bad("missing_fields");
  const [row] = await db
    .insert(users)
    .values({
      username: String(b.username).trim().toLowerCase(),
      fullName: b.fullName || b.username,
      role: b.role || "reception",
      email: b.email || null,
      phone: b.phone || null,
      passwordHash: await hashPassword(b.password),
      isActive: b.isActive ?? true,
    })
    .returning({ id: users.id });
  return ok(row);
});
