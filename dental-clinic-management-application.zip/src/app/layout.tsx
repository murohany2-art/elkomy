import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { LangProvider } from "@/components/lang-provider";

export const metadata: Metadata = {
  title: "Dental Clinic Pro",
  description: "Professional Dental Clinic Management System — نظام إدارة عيادات الأسنان",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body className="antialiased">
        <LangProvider>{children}</LangProvider>
      </body>
    </html>
  );
}
