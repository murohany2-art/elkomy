"use client";
import { useEffect, useState } from "react";
import { api } from "@/lib/format";
import { SplashScreen, ActivationScreen, LoginScreen } from "@/components/auth-screens";
import { AppShell } from "@/components/app-shell";
import type { SessionUser } from "@/lib/auth";

type Phase = "splash" | "activation" | "login" | "app";

export default function Home() {
  const [phase, setPhase] = useState<Phase>("splash");
  const [user, setUser] = useState<SessionUser | null>(null);

  async function bootstrap() {
    try {
      const lic = await api<{ activated: boolean }>("/api/license");
      if (!lic.activated) {
        setPhase("activation");
        return;
      }
      const me = await api<{ user: SessionUser | null }>("/api/auth/me");
      if (me.user) {
        setUser(me.user);
        setPhase("app");
      } else {
        setPhase("login");
      }
    } catch {
      setPhase("login");
    }
  }

  useEffect(() => {
    const timer = setTimeout(bootstrap, 2600);
    return () => clearTimeout(timer);
  }, []);

  async function afterLogin() {
    const me = await api<{ user: SessionUser | null }>("/api/auth/me");
    if (me.user) {
      setUser(me.user);
      setPhase("app");
    }
  }

  if (phase === "splash") return <SplashScreen />;
  if (phase === "activation") return <ActivationScreen onDone={() => setPhase("login")} />;
  if (phase === "login") return <LoginScreen onLogin={afterLogin} />;
  if (phase === "app" && user) return <AppShell user={user} onLogout={() => { setUser(null); setPhase("login"); }} />;
  return <SplashScreen />;
}
