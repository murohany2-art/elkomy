"use client";
import { useState, type ReactNode } from "react";
import { useLang } from "./lang-provider";
import { api } from "@/lib/format";
import {
  DashboardIcon, PatientIcon, CalendarIcon, InvoiceIcon, ToolIcon,
  DoctorIcon, BoxIcon, MoneyIcon, ChartIcon, UsersIcon, SettingsIcon,
  BackupIcon, ToothIcon, LogoutIcon, GlobeIcon, BellIcon,
} from "./icons";
import type { TKey } from "@/lib/i18n";
import type { SessionUser } from "@/lib/auth";

import { DashboardView } from "./views/dashboard-view";
import { PatientsView } from "./views/patients-view";
import { AppointmentsView } from "./views/appointments-view";
import { InvoicesView } from "./views/invoices-view";
import { ServicesView } from "./views/services-view";
import { DoctorsView } from "./views/doctors-view";
import { InventoryView } from "./views/inventory-view";
import { AccountsView } from "./views/accounts-view";
import { ReportsView } from "./views/reports-view";
import { UsersView } from "./views/users-view";
import { SettingsView } from "./views/settings-view";

type NavKey =
  | "dashboard" | "patients" | "appointments" | "invoices" | "services"
  | "doctors" | "inventory" | "accounts" | "reports" | "users" | "settings";

const NAV: { key: NavKey; icon: (p: { className?: string }) => ReactNode; roles?: string[] }[] = [
  { key: "dashboard", icon: DashboardIcon },
  { key: "patients", icon: PatientIcon },
  { key: "appointments", icon: CalendarIcon },
  { key: "invoices", icon: InvoiceIcon },
  { key: "services", icon: ToolIcon },
  { key: "doctors", icon: DoctorIcon },
  { key: "inventory", icon: BoxIcon },
  { key: "accounts", icon: MoneyIcon, roles: ["admin", "accountant"] },
  { key: "reports", icon: ChartIcon, roles: ["admin", "accountant", "doctor"] },
  { key: "users", icon: UsersIcon, roles: ["admin"] },
  { key: "settings", icon: SettingsIcon, roles: ["admin"] },
];

export function AppShell({ user, onLogout }: { user: SessionUser; onLogout: () => void }) {
  const { t, toggle, lang, dir } = useLang();
  const [active, setActive] = useState<NavKey>("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const nav = NAV.filter((n) => !n.roles || n.roles.includes(user.role));

  async function logout() {
    await api("/api/auth/logout", { method: "POST" });
    onLogout();
  }

  const views: Record<NavKey, ReactNode> = {
    dashboard: <DashboardView onNavigate={(k) => setActive(k as NavKey)} />,
    patients: <PatientsView />,
    appointments: <AppointmentsView />,
    invoices: <InvoicesView />,
    services: <ServicesView />,
    doctors: <DoctorsView />,
    inventory: <InventoryView />,
    accounts: <AccountsView />,
    reports: <ReportsView />,
    users: <UsersView />,
    settings: <SettingsView />,
  };

  return (
    <div className="flex min-h-screen bg-slate-100" dir={dir}>
      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 z-40 w-64 transform bg-gradient-to-b from-sky-800 to-indigo-900 text-white transition-transform duration-300 lg:static lg:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : dir === "rtl" ? "translate-x-full" : "-translate-x-full"
        } ltr:left-0 rtl:right-0`}
      >
        <div className="flex items-center gap-2.5 border-b border-white/10 px-5 py-5">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/15">
            <ToothIcon className="h-6 w-6" />
          </div>
          <div>
            <p className="text-sm font-black leading-tight">Dental Clinic</p>
            <p className="text-xs font-bold text-sky-200">PRO</p>
          </div>
        </div>
        <nav className="flex flex-col gap-1 p-3">
          {nav.map((n) => {
            const Icon = n.icon;
            const isActive = active === n.key;
            return (
              <button
                key={n.key}
                onClick={() => {
                  setActive(n.key);
                  setSidebarOpen(false);
                }}
                className={`flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-semibold transition ${
                  isActive ? "bg-white text-sky-800 shadow-md" : "text-sky-100 hover:bg-white/10"
                }`}
              >
                <Icon className="h-5 w-5" />
                {t(n.key as TKey)}
              </button>
            );
          })}
        </nav>
        <div className="absolute bottom-0 w-full border-t border-white/10 p-4 text-xs text-sky-200">
          <p className="font-semibold text-white">{t("designer")}</p>
          <p>{t("founder")}</p>
        </div>
      </aside>

      {sidebarOpen && (
        <div className="fixed inset-0 z-30 bg-black/30 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex items-center justify-between border-b border-slate-200 bg-white/80 px-4 py-3 backdrop-blur lg:px-6">
          <div className="flex items-center gap-3">
            <button className="rounded-lg p-2 hover:bg-slate-100 lg:hidden" onClick={() => setSidebarOpen(true)}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            <span className="text-lg font-extrabold text-slate-800">{t(active as TKey)}</span>
          </div>
          <div className="flex items-center gap-2">
            <button className="relative rounded-xl p-2 text-slate-500 hover:bg-slate-100">
              <BellIcon className="h-5 w-5" />
              <span className="absolute top-1.5 h-2 w-2 rounded-full bg-rose-500 ltr:right-2 rtl:left-2" />
            </button>
            <button
              onClick={toggle}
              className="flex items-center gap-1.5 rounded-xl bg-slate-100 px-3 py-2 text-xs font-bold text-slate-600 hover:bg-slate-200"
            >
              <GlobeIcon className="h-4 w-4" /> {lang === "ar" ? "EN" : "ع"}
            </button>
            <div className="flex items-center gap-2 rounded-xl bg-slate-100 py-1.5 pe-3 ps-1.5">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sky-600 text-sm font-bold text-white">
                {user.fullName?.charAt(0) ?? "U"}
              </div>
              <div className="hidden sm:block">
                <p className="text-xs font-bold leading-tight text-slate-800">{user.fullName}</p>
                <p className="text-[10px] text-slate-500">{t(user.role as TKey)}</p>
              </div>
            </div>
            <button onClick={logout} className="rounded-xl p-2 text-rose-500 hover:bg-rose-50" title={t("logout")}>
              <LogoutIcon className="h-5 w-5" />
            </button>
          </div>
        </header>
        <main className="flex-1 p-4 lg:p-6">{views[active]}</main>
      </div>
    </div>
  );
}
