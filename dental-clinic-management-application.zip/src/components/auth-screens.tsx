"use client";
import { useEffect, useState } from "react";
import { useLang } from "./lang-provider";
import { ToothIcon, ShieldIcon, GlobeIcon } from "./icons";
import { Btn, Input } from "./ui";
import { api } from "@/lib/format";

/* ---------------- Splash Screen ---------------- */
export function SplashScreen() {
  const { t, toggle, lang } = useLang();
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-sky-600 via-sky-700 to-indigo-800 text-white">
      <div className="animate-float mb-6 flex h-32 w-32 items-center justify-center rounded-[2rem] bg-white/15 shadow-2xl backdrop-blur">
        <ToothIcon className="h-20 w-20 text-white" />
      </div>
      <h1 className="text-4xl font-black tracking-tight">Dental Clinic Pro</h1>
      <p className="mt-2 text-sky-100">{t("tagline")}</p>
      <div className="mt-10 h-1 w-56 overflow-hidden rounded-full bg-white/20">
        <div className="h-full w-1/3 animate-[spin-slow_1.2s_linear_infinite] rounded-full bg-white" style={{ animation: "fadeInUp 2s ease" }} />
      </div>
      <div className="absolute bottom-8 text-center text-sm text-sky-100">
        <p className="opacity-80">{t("designedBy")}</p>
        <p className="mt-1 text-base font-bold text-white">{t("designer")}</p>
        <p className="opacity-80">{t("founder")}</p>
        <p className="mt-1 font-mono tracking-widest">01284855036</p>
      </div>
      <button onClick={toggle} className="absolute top-6 flex items-center gap-1.5 rounded-full bg-white/15 px-3 py-1.5 text-sm font-semibold ltr:right-6 rtl:left-6">
        <GlobeIcon className="h-4 w-4" /> {lang === "ar" ? "EN" : "ع"}
      </button>
    </div>
  );
}

/* ---------------- Activation Screen ---------------- */
export function ActivationScreen({ onDone }: { onDone: () => void }) {
  const { t } = useLang();
  const [serial, setSerial] = useState("");
  const [error, setError] = useState("");
  const [demo, setDemo] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api<{ demoSerial: string }>("/api/license").then((d) => setDemo(d.demoSerial)).catch(() => {});
  }, []);

  async function activate() {
    setLoading(true);
    setError("");
    try {
      await api("/api/license", { method: "POST", body: JSON.stringify({ serial }) });
      onDone();
    } catch (e) {
      setError(t((e as Error).message === "serial_used" ? "serialUsed" : "invalidSerial"));
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell icon={<ShieldIcon className="h-10 w-10 text-sky-600" />} title={t("activation")} subtitle={t("activationSubtitle")}>
      <div className="space-y-3">
        <Input
          value={serial}
          onChange={(e) => setSerial(e.target.value.toUpperCase())}
          placeholder="DCP-XXXX-XXXX-XXXX-XXXX"
          className="text-center font-mono tracking-widest"
        />
        {error && <p className="text-sm font-semibold text-rose-500">{error}</p>}
        <Btn className="w-full" onClick={activate} disabled={loading}>
          {loading ? t("loading") : t("activate")}
        </Btn>
        {demo && (
          <button
            onClick={() => setSerial(demo)}
            className="w-full rounded-lg bg-slate-50 px-3 py-2 text-xs text-slate-500 hover:bg-slate-100"
          >
            {t("getDemoSerial")}: <span className="font-mono font-semibold text-sky-600">{demo}</span>
          </button>
        )}
      </div>
    </AuthShell>
  );
}

/* ---------------- Login Screen ---------------- */
export function LoginScreen({ onLogin }: { onLogin: () => void }) {
  const { t } = useLang();
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("admin123");
  const [remember, setRemember] = useState(true);
  const [show, setShow] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      await api("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ username, password, remember }),
      });
      onLogin();
    } catch {
      setError(t("invalidCredentials"));
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell icon={<ToothIcon className="h-10 w-10 text-sky-600" />} title={t("welcomeBack")} subtitle={t("loginSubtitle")}>
      <form onSubmit={submit} className="space-y-4">
        <div>
          <span className="mb-1 block text-xs font-semibold text-slate-500">{t("username")}</span>
          <Input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" />
        </div>
        <div>
          <span className="mb-1 block text-xs font-semibold text-slate-500">{t("password")}</span>
          <div className="relative">
            <Input
              type={show ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
            />
            <button
              type="button"
              onClick={() => setShow((s) => !s)}
              className="absolute top-2 text-xs font-semibold text-sky-600 ltr:right-3 rtl:left-3"
            >
              {show ? t("hidePassword") : t("showPassword")}
            </button>
          </div>
        </div>
        <div className="flex items-center justify-between text-sm">
          <label className="flex items-center gap-2 text-slate-600">
            <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} className="rounded" />
            {t("rememberMe")}
          </label>
          <button type="button" className="font-semibold text-sky-600">{t("forgotPassword")}</button>
        </div>
        {error && <p className="text-sm font-semibold text-rose-500">{error}</p>}
        <Btn type="submit" className="w-full" disabled={loading}>
          {loading ? t("loading") : t("signIn")}
        </Btn>
        <p className="rounded-lg bg-sky-50 p-2 text-center text-xs text-slate-500">
          admin / admin123
        </p>
      </form>
    </AuthShell>
  );
}

function AuthShell({
  icon,
  title,
  subtitle,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  const { toggle, lang } = useLang();
  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-100 to-sky-100 p-4">
      <div className="w-full max-w-md">
        <div className="animate-fade rounded-3xl border border-white bg-white/90 p-8 shadow-2xl backdrop-blur">
          <div className="mb-6 flex flex-col items-center text-center">
            <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-sky-50">{icon}</div>
            <h1 className="text-2xl font-extrabold text-slate-800">{title}</h1>
            <p className="mt-1 text-sm text-slate-500">{subtitle}</p>
          </div>
          {children}
          <button
            onClick={toggle}
            className="mx-auto mt-6 flex items-center gap-1.5 rounded-full bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-200"
          >
            <GlobeIcon className="h-4 w-4" /> {lang === "ar" ? "English" : "العربية"}
          </button>
        </div>
        <p className="mt-4 text-center text-xs text-slate-400">
          Dental Clinic Pro © 2026 — كودر للبرمجيات
        </p>
      </div>
    </div>
  );
}
