"use client";
/** Lightweight dependency-free SVG charts. */
import { type ReactNode } from "react";

export function StatCard({
  label,
  value,
  icon,
  tone = "sky",
}: {
  label: string;
  value: ReactNode;
  icon: ReactNode;
  tone?: "sky" | "indigo" | "emerald" | "amber" | "rose" | "cyan";
}) {
  const tones: Record<string, string> = {
    sky: "from-sky-500 to-sky-600",
    indigo: "from-indigo-500 to-indigo-600",
    emerald: "from-emerald-500 to-emerald-600",
    amber: "from-amber-500 to-amber-500",
    rose: "from-rose-500 to-rose-600",
    cyan: "from-cyan-500 to-cyan-600",
  };
  return (
    <div className="animate-fade flex items-center gap-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <div
        className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${tones[tone]} text-white shadow-md`}
      >
        {icon}
      </div>
      <div className="min-w-0">
        <p className="truncate text-xs font-semibold text-slate-500">{label}</p>
        <p className="truncate text-xl font-extrabold text-slate-800">{value}</p>
      </div>
    </div>
  );
}

export function BarChart({
  data,
  color = "#0ea5e9",
}: {
  data: { label: string; value: number }[];
  color?: string;
}) {
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <div className="flex h-48 items-end justify-between gap-2 pt-2">
      {data.length === 0 && (
        <div className="flex h-full w-full items-center justify-center text-sm text-slate-400">
          —
        </div>
      )}
      {data.map((d, i) => (
        <div key={i} className="flex flex-1 flex-col items-center gap-1.5">
          <div className="flex w-full flex-1 items-end">
            <div
              className="w-full rounded-t-lg transition-all duration-500 hover:opacity-80"
              style={{
                height: `${(d.value / max) * 100}%`,
                minHeight: d.value > 0 ? "6px" : "2px",
                background: `linear-gradient(to top, ${color}, ${color}aa)`,
              }}
              title={String(d.value)}
            />
          </div>
          <span className="truncate text-[10px] font-medium text-slate-500">{d.label}</span>
        </div>
      ))}
    </div>
  );
}

export function LineChart({
  data,
  color = "#6366f1",
}: {
  data: { label: string; value: number }[];
  color?: string;
}) {
  const w = 500;
  const h = 160;
  const pad = 20;
  const max = Math.max(1, ...data.map((d) => d.value));
  const step = data.length > 1 ? (w - pad * 2) / (data.length - 1) : 0;
  const points = data.map((d, i) => {
    const x = pad + i * step;
    const y = h - pad - (d.value / max) * (h - pad * 2);
    return [x, y] as const;
  });
  const path = points.map((p, i) => `${i === 0 ? "M" : "L"} ${p[0]} ${p[1]}`).join(" ");
  const area = `${path} L ${points.at(-1)?.[0] ?? pad} ${h - pad} L ${pad} ${h - pad} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-48 w-full">
      <defs>
        <linearGradient id="lg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {data.length > 0 && <path d={area} fill="url(#lg)" />}
      <path d={path} fill="none" stroke={color} strokeWidth="2.5" strokeLinejoin="round" />
      {points.map((p, i) => (
        <circle key={i} cx={p[0]} cy={p[1]} r="3.5" fill="#fff" stroke={color} strokeWidth="2" />
      ))}
      {data.map((d, i) => (
        <text
          key={i}
          x={pad + i * step}
          y={h - 4}
          textAnchor="middle"
          className="fill-slate-400 text-[9px]"
        >
          {d.label}
        </text>
      ))}
    </svg>
  );
}
