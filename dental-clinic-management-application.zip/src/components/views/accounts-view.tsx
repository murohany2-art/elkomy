"use client";
import { useEffect, useState, useCallback } from "react";
import { useLang } from "../lang-provider";
import { api, money, fmtDate } from "@/lib/format";
import { PageHeader, AddButton, Table, Modal, Field, Input, Select, Btn, Badge, Empty } from "../ui";
import { Th, Td, IconBtn } from "./patients-view";
import { StatCard } from "../charts";
import { MoneyIcon, TrashIcon } from "../icons";
import type { TKey } from "@/lib/i18n";

type Tx = { id: number; type: string; category: string | null; amount: string; description: string | null; party: string | null; createdAt: string };
type Data = { rows: Tx[]; summary: { income: number; expenses: number; balance: number } };

export function AccountsView() {
  const { t, lang } = useLang();
  const [data, setData] = useState<Data | null>(null);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState<{ type?: string; category?: string; amount?: string; description?: string; party?: string }>({ type: "expense" });

  const load = useCallback(() => api<Data>("/api/transactions").then(setData), []);
  useEffect(() => { load(); }, [load]);

  async function save() {
    await api("/api/transactions", { method: "POST", body: JSON.stringify(form) });
    setModal(false); setForm({ type: "expense" }); load();
  }
  async function del(id: number) {
    if (!confirm(t("confirmDelete"))) return;
    await api(`/api/transactions/${id}`, { method: "DELETE" }); load();
  }

  if (!data) return <p className="text-slate-400">{t("loading")}</p>;

  return (
    <div>
      <PageHeader title={t("accounts")} icon={<MoneyIcon className="h-6 w-6" />}
        action={<AddButton label={t("add")} onClick={() => setModal(true)} />} />
      <div className="mb-5 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard label={t("income")} value={money(data.summary.income, "EGP", lang)} icon={<MoneyIcon className="h-6 w-6" />} tone="emerald" />
        <StatCard label={t("expenses")} value={money(data.summary.expenses, "EGP", lang)} icon={<MoneyIcon className="h-6 w-6" />} tone="rose" />
        <StatCard label={t("treasury")} value={money(data.summary.balance, "EGP", lang)} icon={<MoneyIcon className="h-6 w-6" />} tone="sky" />
      </div>
      {data.rows.length === 0 ? <Empty text={t("noData")} /> : (
        <Table head={<><Th>{t("type")}</Th><Th>{t("category")}</Th><Th>{t("amount")}</Th><Th>{t("description")}</Th><Th>{t("date")}</Th><Th>{t("actions")}</Th></>}>
          {data.rows.map((x) => (
            <tr key={x.id} className="hover:bg-slate-50">
              <Td><Badge color={x.type === "income" ? "green" : "red"}>{t(x.type as TKey)}</Badge></Td>
              <Td>{x.category ?? "-"}</Td>
              <Td className={`font-bold ${x.type === "income" ? "text-emerald-600" : "text-rose-500"}`}>{money(x.amount, "EGP", lang)}</Td>
              <Td>{x.description ?? "-"}</Td>
              <Td>{fmtDate(x.createdAt, lang)}</Td>
              <Td><IconBtn onClick={() => del(x.id)} title={t("delete")} tone="red"><TrashIcon className="h-4 w-4" /></IconBtn></Td>
            </tr>
          ))}
        </Table>
      )}
      <Modal open={modal} onClose={() => setModal(false)} title={t("add")}>
        <div className="space-y-3">
          <Field label={t("type")}>
            <Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
              <option value="expense">{t("expenses")}</option>
              <option value="income">{t("income")}</option>
            </Select>
          </Field>
          <Field label={t("category")}><Input value={form.category ?? ""} onChange={(e) => setForm({ ...form, category: e.target.value })} /></Field>
          <Field label={t("amount")}><Input type="number" value={form.amount ?? ""} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></Field>
          <Field label={t("description")}><Input value={form.description ?? ""} onChange={(e) => setForm({ ...form, description: e.target.value })} /></Field>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <Btn variant="ghost" onClick={() => setModal(false)}>{t("cancel")}</Btn>
          <Btn onClick={save} disabled={!form.amount}>{t("save")}</Btn>
        </div>
      </Modal>
    </div>
  );
}
