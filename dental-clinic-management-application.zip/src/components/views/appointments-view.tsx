"use client";
import { useEffect, useState, useCallback } from "react";
import { useLang } from "../lang-provider";
import { api, fmtTime, fmtDate } from "@/lib/format";
import { PageHeader, AddButton, Modal, Field, Input, Select, Btn, Badge, Empty, Card } from "../ui";
import { CalendarIcon, TrashIcon } from "../icons";
import type { TKey } from "@/lib/i18n";

type Appt = {
  id: number; patientId: number | null; doctorId: number | null; serviceId: number | null;
  startTime: string; endTime: string | null; status: string; notes: string | null;
  patientName: string | null; doctorName: string | null; serviceName: string | null; doctorColor: string | null;
};
type Ref = { id: number; name: string };

const STATUSES = ["scheduled", "confirmed", "completed", "cancelled", "no_show"];
const statusColor = (s: string) =>
  s === "completed" ? "green" : s === "confirmed" ? "sky" : s === "cancelled" ? "red" : s === "no_show" ? "amber" : "indigo";

export function AppointmentsView() {
  const { t, lang } = useLang();
  const [rows, setRows] = useState<Appt[]>([]);
  const [patients, setPatients] = useState<Ref[]>([]);
  const [doctors, setDoctors] = useState<Ref[]>([]);
  const [services, setServices] = useState<Ref[]>([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState<{ patientId?: string; doctorId?: string; serviceId?: string; startTime?: string; status?: string; notes?: string }>({});

  const load = useCallback(() => api<Appt[]>("/api/appointments").then(setRows), []);
  useEffect(() => {
    load();
    api<Ref[]>("/api/patients").then(setPatients);
    api<Ref[]>("/api/doctors").then(setDoctors);
    api<Ref[]>("/api/services").then(setServices);
  }, [load]);

  async function save() {
    await api("/api/appointments", { method: "POST", body: JSON.stringify(form) });
    setModal(false);
    setForm({});
    load();
  }
  async function changeStatus(id: number, status: string) {
    await api(`/api/appointments/${id}`, { method: "PUT", body: JSON.stringify({ status }) });
    load();
  }
  async function del(id: number) {
    if (!confirm(t("confirmDelete"))) return;
    await api(`/api/appointments/${id}`, { method: "DELETE" });
    load();
  }

  // Group by date
  const groups = rows.reduce<Record<string, Appt[]>>((acc, a) => {
    const key = new Date(a.startTime).toDateString();
    (acc[key] ??= []).push(a);
    return acc;
  }, {});

  return (
    <div>
      <PageHeader
        title={t("appointments")}
        icon={<CalendarIcon className="h-6 w-6" />}
        action={<AddButton label={t("add")} onClick={() => setModal(true)} />}
      />
      {rows.length === 0 ? (
        <Empty text={t("noData")} />
      ) : (
        <div className="grid gap-4 lg:grid-cols-2 xl:grid-cols-3">
          {Object.entries(groups).map(([day, items]) => (
            <Card key={day}>
              <h3 className="mb-3 flex items-center gap-2 font-bold text-slate-700">
                <CalendarIcon className="h-4 w-4 text-sky-600" />
                {fmtDate(items[0].startTime, lang)}
              </h3>
              <ul className="space-y-2">
                {items.map((a) => (
                  <li key={a.id} className="rounded-xl border border-slate-100 bg-slate-50 p-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="h-8 w-1 rounded-full" style={{ background: a.doctorColor ?? "#0ea5e9" }} />
                        <div>
                          <p className="text-sm font-bold text-slate-700">{a.patientName ?? "-"}</p>
                          <p className="text-xs text-slate-500">{a.doctorName ?? "-"} · {a.serviceName ?? "-"}</p>
                        </div>
                      </div>
                      <span className="text-xs font-semibold text-slate-500">{fmtTime(a.startTime, lang)}</span>
                    </div>
                    <div className="mt-2 flex items-center justify-between">
                      <Badge color={statusColor(a.status)}>{t(a.status as TKey)}</Badge>
                      <div className="flex items-center gap-1">
                        <select
                          value={a.status}
                          onChange={(e) => changeStatus(a.id, e.target.value)}
                          className="rounded-lg border border-slate-200 bg-white px-2 py-1 text-xs"
                        >
                          {STATUSES.map((s) => <option key={s} value={s}>{t(s as TKey)}</option>)}
                        </select>
                        <button onClick={() => del(a.id)} className="rounded-lg p-1 text-rose-500 hover:bg-rose-50">
                          <TrashIcon className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={t("add")}>
        <div className="space-y-3">
          <Field label={t("patients")}>
            <Select value={form.patientId ?? ""} onChange={(e) => setForm({ ...form, patientId: e.target.value })}>
              <option value="">-</option>
              {patients.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </Select>
          </Field>
          <Field label={t("doctor")}>
            <Select value={form.doctorId ?? ""} onChange={(e) => setForm({ ...form, doctorId: e.target.value })}>
              <option value="">-</option>
              {doctors.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </Select>
          </Field>
          <Field label={t("services")}>
            <Select value={form.serviceId ?? ""} onChange={(e) => setForm({ ...form, serviceId: e.target.value })}>
              <option value="">-</option>
              {services.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
          </Field>
          <Field label={`${t("date")} / ${t("time")}`}>
            <Input type="datetime-local" value={form.startTime ?? ""} onChange={(e) => setForm({ ...form, startTime: e.target.value })} />
          </Field>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <Btn variant="ghost" onClick={() => setModal(false)}>{t("cancel")}</Btn>
          <Btn onClick={save} disabled={!form.patientId || !form.startTime}>{t("save")}</Btn>
        </div>
      </Modal>
    </div>
  );
}
