"use client";
import { useEffect, useState } from "react";
import { useLang } from "../lang-provider";
import { api, money, fmtDate } from "@/lib/format";
import { Card, Badge, Empty } from "../ui";
import { StatCard, BarChart, LineChart } from "../charts";
import {
  PatientIcon, CalendarIcon, DoctorIcon, MoneyIcon,
  InvoiceIcon, BoxIcon, ChartIcon,
} from "../icons";

type Dash = {
  totals: {
    patients: number; doctors: number; invoices: number; todayAppointments: number;
    dailyRevenue: number; monthlyRevenue: number; paid: number; outstanding: number;
  };
  daily: { day: string; value: number }[];
  monthly: { month: string; value: number }[];
  recentPatients: { id: number; name: string; fileNumber: string; createdAt: string }[];
  recentInvoices: { id: number; invoiceNumber: string; total: string; status: string; patientName: string }[];
  lowStock: { id: number; name: string; quantity: number; minQuantity: number }[];
};

export function DashboardView({ onNavigate }: { onNavigate: (k: string) => void }) {
  const { t, lang } = useLang();
  const [d, setD] = useState<Dash | null>(null);

  useEffect(() => {
    api<Dash>("/api/dashboard").then(setD).catch(() => {});
  }, []);

  if (!d) return <p className="text-slate-400">{t("loading")}</p>;

  const weekdayShort = (day: string) => {
    const dt = new Date(day);
    return dt.toLocaleDateString(lang === "ar" ? "ar-EG" : "en", { weekday: "short" });
  };
  const monthShort = (m: string) => {
    const dt = new Date(m + "-01");
    return dt.toLocaleDateString(lang === "ar" ? "ar-EG" : "en", { month: "short" });
  };

  const statusColor = (s: string) =>
    s === "paid" ? "green" : s === "partial" ? "amber" : "red";

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label={t("totalPatients")} value={d.totals.patients} icon={<PatientIcon className="h-6 w-6" />} tone="sky" />
        <StatCard label={t("todayAppointments")} value={d.totals.todayAppointments} icon={<CalendarIcon className="h-6 w-6" />} tone="indigo" />
        <StatCard label={t("totalDoctors")} value={d.totals.doctors} icon={<DoctorIcon className="h-6 w-6" />} tone="cyan" />
        <StatCard label={t("totalInvoices")} value={d.totals.invoices} icon={<InvoiceIcon className="h-6 w-6" />} tone="emerald" />
        <StatCard label={t("dailyRevenue")} value={money(d.totals.dailyRevenue, "EGP", lang)} icon={<MoneyIcon className="h-6 w-6" />} tone="emerald" />
        <StatCard label={t("monthlyRevenue")} value={money(d.totals.monthlyRevenue, "EGP", lang)} icon={<ChartIcon className="h-6 w-6" />} tone="sky" />
        <StatCard label={t("totalPaid")} value={money(d.totals.paid, "EGP", lang)} icon={<MoneyIcon className="h-6 w-6" />} tone="indigo" />
        <StatCard label={t("outstanding")} value={money(d.totals.outstanding, "EGP", lang)} icon={<MoneyIcon className="h-6 w-6" />} tone="rose" />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <h3 className="mb-3 font-bold text-slate-700">{t("dailyChart")}</h3>
          <BarChart data={d.daily.map((x) => ({ label: weekdayShort(x.day), value: Number(x.value) }))} />
        </Card>
        <Card>
          <h3 className="mb-3 font-bold text-slate-700">{t("monthlyChart")}</h3>
          <LineChart data={d.monthly.map((x) => ({ label: monthShort(x.month), value: Number(x.value) }))} />
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card>
          <h3 className="mb-3 font-bold text-slate-700">{t("recentPatients")}</h3>
          {d.recentPatients.length === 0 ? (
            <Empty text={t("noData")} />
          ) : (
            <ul className="space-y-2">
              {d.recentPatients.map((p) => (
                <li key={p.id} className="flex items-center justify-between rounded-xl bg-slate-50 px-3 py-2">
                  <div className="flex items-center gap-2">
                    <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sky-100 text-sm font-bold text-sky-700">
                      {p.name.charAt(0)}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-700">{p.name}</p>
                      <p className="text-xs text-slate-400">{p.fileNumber}</p>
                    </div>
                  </div>
                  <span className="text-xs text-slate-400">{fmtDate(p.createdAt, lang)}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card>
          <h3 className="mb-3 font-bold text-slate-700">{t("recentOperations")}</h3>
          {d.recentInvoices.length === 0 ? (
            <Empty text={t("noData")} />
          ) : (
            <ul className="space-y-2">
              {d.recentInvoices.map((i) => (
                <li key={i.id} className="flex items-center justify-between rounded-xl bg-slate-50 px-3 py-2">
                  <div>
                    <p className="text-sm font-semibold text-slate-700">{i.patientName ?? "-"}</p>
                    <p className="text-xs text-slate-400">{i.invoiceNumber}</p>
                  </div>
                  <div className="text-end">
                    <p className="text-sm font-bold text-slate-700">{money(i.total, "EGP", lang)}</p>
                    <Badge color={statusColor(i.status)}>{t(i.status as never)}</Badge>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card>
          <h3 className="mb-3 flex items-center gap-2 font-bold text-slate-700">
            <BoxIcon className="h-5 w-5 text-amber-500" /> {t("notifications")}
          </h3>
          {d.lowStock.length === 0 ? (
            <Empty text={t("noData")} />
          ) : (
            <ul className="space-y-2">
              {d.lowStock.map((s) => (
                <li key={s.id} className="flex items-center justify-between rounded-xl bg-amber-50 px-3 py-2">
                  <div>
                    <p className="text-sm font-semibold text-amber-800">{s.name}</p>
                    <p className="text-xs text-amber-600">{t("lowStockAlert")}</p>
                  </div>
                  <Badge color="red">{s.quantity}/{s.minQuantity}</Badge>
                </li>
              ))}
              <li>
                <button onClick={() => onNavigate("inventory")} className="mt-1 text-xs font-semibold text-sky-600">
                  {t("inventory")} →
                </button>
              </li>
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
