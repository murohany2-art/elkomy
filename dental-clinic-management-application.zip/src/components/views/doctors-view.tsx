"use client";
import { useEffect, useState, useCallback } from "react";
import { useLang } from "../lang-provider";
import { api, money } from "@/lib/format";
import { PageHeader, AddButton, Modal, Field, Input, Btn, Empty, Card } from "../ui";
import { DoctorIcon, EditIcon, TrashIcon } from "../icons";

type Doc = {
  id: number; name: string; specialty: string | null; phone: string | null;
  email: string | null; commissionRate: string | null; salary: string | null; color: string | null;
};

export function DoctorsView() {
  const { t, lang } = useLang();
  const [rows, setRows] = useState<Doc[]>([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState<Partial<Doc>>({});

  const load = useCallback(() => api<Doc[]>("/api/doctors").then(setRows), []);
  useEffect(() => { load(); }, [load]);

  async function save() {
    const url = form.id ? `/api/doctors/${form.id}` : "/api/doctors";
    await api(url, { method: form.id ? "PUT" : "POST", body: JSON.stringify(form) });
    setModal(false); setForm({}); load();
  }
  async function del(id: number) {
    if (!confirm(t("confirmDelete"))) return;
    await api(`/api/doctors/${id}`, { method: "DELETE" }); load();
  }

  return (
    <div>
      <PageHeader title={t("doctors")} icon={<DoctorIcon className="h-6 w-6" />}
        action={<AddButton label={t("add")} onClick={() => { setForm({ color: "#0ea5e9" }); setModal(true); }} />} />
      {rows.length === 0 ? <Empty text={t("noData")} /> : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map((d) => (
            <Card key={d.id}>
              <div className="flex items-start gap-3">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl text-white" style={{ background: d.color ?? "#0ea5e9" }}>
                  <DoctorIcon className="h-7 w-7" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-bold text-slate-800">{d.name}</p>
                  <p className="text-xs text-slate-500">{d.specialty ?? "-"}</p>
                  <p dir="ltr" className="mt-1 text-start text-xs text-slate-400">{d.phone ?? "-"}</p>
                </div>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                <div className="rounded-lg bg-slate-50 px-2 py-1.5"><span className="text-xs text-slate-400">{t("commission")}</span><p className="font-bold text-slate-700">{d.commissionRate}%</p></div>
                <div className="rounded-lg bg-slate-50 px-2 py-1.5"><span className="text-xs text-slate-400">{t("salary")}</span><p className="font-bold text-slate-700">{money(d.salary, "EGP", lang)}</p></div>
              </div>
              <div className="mt-3 flex justify-end gap-1">
                <button onClick={() => { setForm(d); setModal(true); }} className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100"><EditIcon className="h-4 w-4" /></button>
                <button onClick={() => del(d.id)} className="rounded-lg p-1.5 text-rose-500 hover:bg-rose-50"><TrashIcon className="h-4 w-4" /></button>
              </div>
            </Card>
          ))}
        </div>
      )}
      <Modal open={modal} onClose={() => setModal(false)} title={form.id ? t("edit") : t("add")}>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label={t("name")}><Input value={form.name ?? ""} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label={t("specialty")}><Input value={form.specialty ?? ""} onChange={(e) => setForm({ ...form, specialty: e.target.value })} /></Field>
          <Field label={t("phone")}><Input dir="ltr" value={form.phone ?? ""} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
          <Field label={t("email")}><Input dir="ltr" value={form.email ?? ""} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
          <Field label={t("commission")}><Input type="number" value={form.commissionRate ?? ""} onChange={(e) => setForm({ ...form, commissionRate: e.target.value })} /></Field>
          <Field label={t("salary")}><Input type="number" value={form.salary ?? ""} onChange={(e) => setForm({ ...form, salary: e.target.value })} /></Field>
          <Field label="Color"><Input type="color" value={form.color ?? "#0ea5e9"} onChange={(e) => setForm({ ...form, color: e.target.value })} /></Field>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <Btn variant="ghost" onClick={() => setModal(false)}>{t("cancel")}</Btn>
          <Btn onClick={save} disabled={!form.name}>{t("save")}</Btn>
        </div>
      </Modal>
    </div>
  );
}
