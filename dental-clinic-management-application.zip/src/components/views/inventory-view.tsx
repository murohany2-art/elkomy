"use client";
import { useEffect, useState, useCallback } from "react";
import { useLang } from "../lang-provider";
import { api, money } from "@/lib/format";
import { PageHeader, AddButton, Table, Modal, Field, Input, Select, Btn, Badge, Empty } from "../ui";
import { Th, Td, IconBtn } from "./patients-view";
import { BoxIcon, EditIcon, TrashIcon } from "../icons";
import type { TKey } from "@/lib/i18n";

type Item = {
  id: number; name: string; category: string | null; barcode: string | null;
  quantity: number; minQuantity: number; unitPrice: string | null; supplier: string | null;
};
const CATS = ["medicine", "material", "tool"];

export function InventoryView() {
  const { t, lang } = useLang();
  const [rows, setRows] = useState<Item[]>([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState<Partial<Item>>({});

  const load = useCallback(() => api<Item[]>("/api/inventory").then(setRows), []);
  useEffect(() => { load(); }, [load]);

  async function save() {
    const url = form.id ? `/api/inventory/${form.id}` : "/api/inventory";
    await api(url, { method: form.id ? "PUT" : "POST", body: JSON.stringify(form) });
    setModal(false); setForm({}); load();
  }
  async function del(id: number) {
    if (!confirm(t("confirmDelete"))) return;
    await api(`/api/inventory/${id}`, { method: "DELETE" }); load();
  }

  return (
    <div>
      <PageHeader title={t("inventory")} icon={<BoxIcon className="h-6 w-6" />}
        action={<AddButton label={t("add")} onClick={() => { setForm({ category: "material" }); setModal(true); }} />} />
      {rows.length === 0 ? <Empty text={t("noData")} /> : (
        <Table head={<><Th>{t("name")}</Th><Th>{t("category")}</Th><Th>{t("barcode")}</Th><Th>{t("quantity")}</Th><Th>{t("minQuantity")}</Th><Th>{t("price")}</Th><Th>{t("supplier")}</Th><Th>{t("actions")}</Th></>}>
          {rows.map((s) => (
            <tr key={s.id} className="hover:bg-slate-50">
              <Td className="font-semibold text-slate-700">{s.name}</Td>
              <Td>{s.category ? t(s.category as TKey) : "-"}</Td>
              <Td className="font-mono text-xs">{s.barcode ?? "-"}</Td>
              <Td>
                {s.quantity <= s.minQuantity ? <Badge color="red">{s.quantity}</Badge> : <span className="font-semibold text-slate-700">{s.quantity}</span>}
              </Td>
              <Td>{s.minQuantity}</Td>
              <Td>{money(s.unitPrice, "EGP", lang)}</Td>
              <Td>{s.supplier ?? "-"}</Td>
              <Td>
                <div className="flex gap-1">
                  <IconBtn onClick={() => { setForm(s); setModal(true); }} title={t("edit")} tone="slate"><EditIcon className="h-4 w-4" /></IconBtn>
                  <IconBtn onClick={() => del(s.id)} title={t("delete")} tone="red"><TrashIcon className="h-4 w-4" /></IconBtn>
                </div>
              </Td>
            </tr>
          ))}
        </Table>
      )}
      <Modal open={modal} onClose={() => setModal(false)} title={form.id ? t("edit") : t("add")}>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label={t("name")}><Input value={form.name ?? ""} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label={t("category")}>
            <Select value={form.category ?? "material"} onChange={(e) => setForm({ ...form, category: e.target.value })}>
              {CATS.map((c) => <option key={c} value={c}>{t(c as TKey)}</option>)}
            </Select>
          </Field>
          <Field label={t("barcode")}><Input dir="ltr" value={form.barcode ?? ""} onChange={(e) => setForm({ ...form, barcode: e.target.value })} /></Field>
          <Field label={t("supplier")}><Input value={form.supplier ?? ""} onChange={(e) => setForm({ ...form, supplier: e.target.value })} /></Field>
          <Field label={t("quantity")}><Input type="number" value={form.quantity ?? 0} onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })} /></Field>
          <Field label={t("minQuantity")}><Input type="number" value={form.minQuantity ?? 5} onChange={(e) => setForm({ ...form, minQuantity: Number(e.target.value) })} /></Field>
          <Field label={t("price")}><Input type="number" value={form.unitPrice ?? ""} onChange={(e) => setForm({ ...form, unitPrice: e.target.value })} /></Field>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <Btn variant="ghost" onClick={() => setModal(false)}>{t("cancel")}</Btn>
          <Btn onClick={save} disabled={!form.name}>{t("save")}</Btn>
        </div>
      </Modal>
    </div>
  );
}
