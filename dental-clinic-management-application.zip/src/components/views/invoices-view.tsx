"use client";
import { useEffect, useState, useCallback } from "react";
import { useLang } from "../lang-provider";
import { api, money, fmtDate } from "@/lib/format";
import { PageHeader, AddButton, Table, Modal, Field, Input, Select, Btn, Badge, Empty } from "../ui";
import { Th, Td, IconBtn } from "./patients-view";
import { InvoiceIcon, TrashIcon, PlusIcon } from "../icons";
import type { TKey } from "@/lib/i18n";

type Inv = {
  id: number; invoiceNumber: string; patientName: string | null; doctorName: string | null;
  total: string; paid: string; status: string; paymentMethod: string; createdAt: string;
};
type Ref = { id: number; name: string };
type Svc = { id: number; name: string; price: string };
type Line = { serviceId?: number; description: string; quantity: number; unitPrice: number };

const statusColor = (s: string) => (s === "paid" ? "green" : s === "partial" ? "amber" : "red");
const METHODS = ["cash", "card", "transfer", "wallet"];

export function InvoicesView() {
  const { t, lang } = useLang();
  const [rows, setRows] = useState<Inv[]>([]);
  const [patients, setPatients] = useState<Ref[]>([]);
  const [doctors, setDoctors] = useState<Ref[]>([]);
  const [services, setServices] = useState<Svc[]>([]);
  const [modal, setModal] = useState(false);
  const [view, setView] = useState<number | null>(null);

  const [patientId, setPatientId] = useState("");
  const [doctorId, setDoctorId] = useState("");
  const [method, setMethod] = useState("cash");
  const [discount, setDiscount] = useState(0);
  const [taxRate, setTaxRate] = useState(14);
  const [paid, setPaid] = useState(0);
  const [lines, setLines] = useState<Line[]>([]);

  const load = useCallback(() => api<Inv[]>("/api/invoices").then(setRows), []);
  useEffect(() => {
    load();
    api<Ref[]>("/api/patients").then(setPatients);
    api<Ref[]>("/api/doctors").then(setDoctors);
    api<Svc[]>("/api/services").then(setServices);
  }, [load]);

  const subtotal = lines.reduce((s, l) => s + l.unitPrice * l.quantity, 0);
  const tax = ((subtotal - discount) * taxRate) / 100;
  const total = subtotal - discount + tax;

  function reset() {
    setPatientId(""); setDoctorId(""); setMethod("cash"); setDiscount(0); setPaid(0); setLines([]);
  }
  function addLine() {
    setLines([...lines, { description: "", quantity: 1, unitPrice: 0 }]);
  }
  function setLine(i: number, patch: Partial<Line>) {
    setLines(lines.map((l, idx) => (idx === i ? { ...l, ...patch } : l)));
  }
  function pickService(i: number, id: string) {
    const svc = services.find((s) => s.id === Number(id));
    if (svc) setLine(i, { serviceId: svc.id, description: svc.name, unitPrice: Number(svc.price) });
  }
  async function save() {
    await api("/api/invoices", {
      method: "POST",
      body: JSON.stringify({ patientId, doctorId, paymentMethod: method, discount, tax, paid, items: lines }),
    });
    setModal(false);
    reset();
    load();
  }
  async function del(id: number) {
    if (!confirm(t("confirmDelete"))) return;
    await api(`/api/invoices/${id}`, { method: "DELETE" });
    load();
  }

  return (
    <div>
      <PageHeader
        title={t("invoices")}
        icon={<InvoiceIcon className="h-6 w-6" />}
        action={<AddButton label={t("add")} onClick={() => { reset(); addLine(); setModal(true); }} />}
      />
      {rows.length === 0 ? (
        <Empty text={t("noData")} />
      ) : (
        <Table
          head={
            <>
              <Th>{t("invoiceNumber")}</Th>
              <Th>{t("patients")}</Th>
              <Th>{t("total")}</Th>
              <Th>{t("paid")}</Th>
              <Th>{t("remaining")}</Th>
              <Th>{t("paymentMethod")}</Th>
              <Th>{t("status")}</Th>
              <Th>{t("date")}</Th>
              <Th>{t("actions")}</Th>
            </>
          }
        >
          {rows.map((i) => (
            <tr key={i.id} className="hover:bg-slate-50">
              <Td className="font-mono text-xs">{i.invoiceNumber}</Td>
              <Td className="font-semibold text-slate-700">{i.patientName ?? "-"}</Td>
              <Td>{money(i.total, "EGP", lang)}</Td>
              <Td className="text-emerald-600">{money(i.paid, "EGP", lang)}</Td>
              <Td className="text-rose-500">{money(Number(i.total) - Number(i.paid), "EGP", lang)}</Td>
              <Td>{t(i.paymentMethod as TKey)}</Td>
              <Td><Badge color={statusColor(i.status)}>{t(i.status as TKey)}</Badge></Td>
              <Td>{fmtDate(i.createdAt, lang)}</Td>
              <Td>
                <div className="flex gap-1">
                  <IconBtn onClick={() => setView(i.id)} title={t("view")} tone="sky"><InvoiceIcon className="h-4 w-4" /></IconBtn>
                  <IconBtn onClick={() => del(i.id)} title={t("delete")} tone="red"><TrashIcon className="h-4 w-4" /></IconBtn>
                </div>
              </Td>
            </tr>
          ))}
        </Table>
      )}

      {/* Builder */}
      <Modal open={modal} onClose={() => setModal(false)} title={t("add")} wide>
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label={t("patients")}>
            <Select value={patientId} onChange={(e) => setPatientId(e.target.value)}>
              <option value="">-</option>
              {patients.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </Select>
          </Field>
          <Field label={t("doctor")}>
            <Select value={doctorId} onChange={(e) => setDoctorId(e.target.value)}>
              <option value="">-</option>
              {doctors.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </Select>
          </Field>
          <Field label={t("paymentMethod")}>
            <Select value={method} onChange={(e) => setMethod(e.target.value)}>
              {METHODS.map((m) => <option key={m} value={m}>{t(m as TKey)}</option>)}
            </Select>
          </Field>
        </div>

        <div className="mt-4 space-y-2">
          {lines.map((l, i) => (
            <div key={i} className="grid grid-cols-12 items-center gap-2">
              <div className="col-span-4">
                <Select value={l.serviceId ?? ""} onChange={(e) => pickService(i, e.target.value)}>
                  <option value="">{t("services")}</option>
                  {services.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </Select>
              </div>
              <div className="col-span-3">
                <Input placeholder={t("description")} value={l.description} onChange={(e) => setLine(i, { description: e.target.value })} />
              </div>
              <div className="col-span-2">
                <Input type="number" min={1} value={l.quantity} onChange={(e) => setLine(i, { quantity: Number(e.target.value) })} />
              </div>
              <div className="col-span-2">
                <Input type="number" value={l.unitPrice} onChange={(e) => setLine(i, { unitPrice: Number(e.target.value) })} />
              </div>
              <button onClick={() => setLines(lines.filter((_, idx) => idx !== i))} className="col-span-1 rounded-lg p-2 text-rose-500 hover:bg-rose-50">
                <TrashIcon className="h-4 w-4" />
              </button>
            </div>
          ))}
          <button onClick={addLine} className="flex items-center gap-1 text-sm font-semibold text-sky-600">
            <PlusIcon className="h-4 w-4" /> {t("add")}
          </button>
        </div>

        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          <Field label={t("discount")}><Input type="number" value={discount} onChange={(e) => setDiscount(Number(e.target.value))} /></Field>
          <Field label={t("taxRate")}><Input type="number" value={taxRate} onChange={(e) => setTaxRate(Number(e.target.value))} /></Field>
          <Field label={t("paid")}><Input type="number" value={paid} onChange={(e) => setPaid(Number(e.target.value))} /></Field>
        </div>

        <div className="mt-4 space-y-1 rounded-xl bg-slate-50 p-4 text-sm">
          <Row label={t("subtotal")} value={money(subtotal, "EGP", lang)} />
          <Row label={t("discount")} value={money(discount, "EGP", lang)} />
          <Row label={t("tax")} value={money(tax, "EGP", lang)} />
          <div className="border-t border-slate-200 pt-1"><Row label={t("total")} value={money(total, "EGP", lang)} bold /></div>
          <Row label={t("remaining")} value={money(total - paid, "EGP", lang)} />
        </div>

        <div className="mt-5 flex justify-end gap-2">
          <Btn variant="ghost" onClick={() => setModal(false)}>{t("cancel")}</Btn>
          <Btn onClick={save} disabled={!patientId || lines.length === 0}>{t("save")}</Btn>
        </div>
      </Modal>

      {view && <InvoicePrint id={view} onClose={() => setView(null)} onPaid={load} />}
    </div>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className={`flex justify-between ${bold ? "font-bold text-slate-800" : "text-slate-600"}`}>
      <span>{label}</span><span>{value}</span>
    </div>
  );
}

type FullInv = {
  invoiceNumber: string; patientName: string | null; patientPhone: string | null; doctorName: string | null;
  subtotal: string; discount: string; tax: string; total: string; paid: string; status: string;
  paymentMethod: string; createdAt: string;
  items: { id: number; description: string; quantity: number; unitPrice: string; total: string }[];
};

function InvoicePrint({ id, onClose, onPaid }: { id: number; onClose: () => void; onPaid: () => void }) {
  const { t, lang } = useLang();
  const [inv, setInv] = useState<FullInv | null>(null);

  useEffect(() => {
    api<FullInv>(`/api/invoices/${id}`).then(setInv);
  }, [id]);

  async function markPaid() {
    if (!inv) return;
    await api(`/api/invoices/${id}`, { method: "PUT", body: JSON.stringify({ paid: Number(inv.total) }) });
    api<FullInv>(`/api/invoices/${id}`).then(setInv);
    onPaid();
  }

  if (!inv) return null;
  return (
    <Modal open onClose={onClose} title={t("printInvoice")} wide>
      <div className="print-area rounded-xl border border-slate-200 p-6">
        <div className="mb-6 flex items-center justify-between border-b border-slate-200 pb-4">
          <div>
            <h2 className="text-2xl font-black text-sky-700">Dental Clinic Pro</h2>
            <p className="text-xs text-slate-500">01284855036 · القاهرة، مصر</p>
          </div>
          <div className="text-end">
            <p className="font-mono text-sm font-bold">{inv.invoiceNumber}</p>
            <p className="text-xs text-slate-500">{fmtDate(inv.createdAt, lang)}</p>
          </div>
        </div>
        <div className="mb-4 grid grid-cols-2 gap-2 text-sm">
          <p><b>{t("patients")}:</b> {inv.patientName ?? "-"}</p>
          <p><b>{t("doctor")}:</b> {inv.doctorName ?? "-"}</p>
          <p><b>{t("phone")}:</b> <span dir="ltr">{inv.patientPhone ?? "-"}</span></p>
          <p><b>{t("paymentMethod")}:</b> {t(inv.paymentMethod as TKey)}</p>
        </div>
        <table className="w-full text-sm">
          <thead className="bg-slate-100 text-xs">
            <tr>
              <th className="p-2 text-start">{t("description")}</th>
              <th className="p-2">{t("quantity")}</th>
              <th className="p-2">{t("price")}</th>
              <th className="p-2">{t("total")}</th>
            </tr>
          </thead>
          <tbody>
            {inv.items.map((it) => (
              <tr key={it.id} className="border-b border-slate-100">
                <td className="p-2">{it.description}</td>
                <td className="p-2 text-center">{it.quantity}</td>
                <td className="p-2 text-center">{money(it.unitPrice, "EGP", lang)}</td>
                <td className="p-2 text-center">{money(it.total, "EGP", lang)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="mt-4 ms-auto max-w-xs space-y-1 text-sm">
          <Row label={t("subtotal")} value={money(inv.subtotal, "EGP", lang)} />
          <Row label={t("discount")} value={money(inv.discount, "EGP", lang)} />
          <Row label={t("tax")} value={money(inv.tax, "EGP", lang)} />
          <Row label={t("total")} value={money(inv.total, "EGP", lang)} bold />
          <Row label={t("paid")} value={money(inv.paid, "EGP", lang)} />
          <Row label={t("remaining")} value={money(Number(inv.total) - Number(inv.paid), "EGP", lang)} />
        </div>
        <p className="mt-6 text-center text-xs text-slate-400">Dental Clinic Pro — كودر للبرمجيات</p>
      </div>
      <div className="no-print mt-5 flex justify-end gap-2">
        {inv.status !== "paid" && <Btn variant="success" onClick={markPaid}>{t("paid")}</Btn>}
        <Btn onClick={() => window.print()}>{t("print")}</Btn>
        <Btn variant="ghost" onClick={onClose}>{t("cancel")}</Btn>
      </div>
    </Modal>
  );
}
