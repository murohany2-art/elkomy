"use client";
import { useEffect, useState, useCallback } from "react";
import { useLang } from "../lang-provider";
import { api, calcAge, fmtDate } from "@/lib/format";
import {
  PageHeader, AddButton, SearchBar, Table, Modal, Field, Input, Textarea,
  Select, Btn, Badge, Empty,
} from "../ui";
import { PatientIcon, EditIcon, TrashIcon, ToothIcon, XrayIcon } from "../icons";
import type { TKey } from "@/lib/i18n";

type Patient = {
  id: number; fileNumber: string; name: string; gender: string;
  birthDate: string | null; phone: string | null; email: string | null;
  status: string; doctorId: number | null; doctorName: string | null;
};
type Doctor = { id: number; name: string };
type Full = Patient & {
  address?: string; occupation?: string; maritalStatus?: string; notes?: string;
  medicalHistory?: string; medications?: string; allergies?: string;
  chronicDiseases?: string; bloodPressure?: string; bloodSugar?: string; treatmentPlan?: string;
};

const empty: Partial<Full> = { name: "", gender: "male", status: "active" };

export function PatientsView() {
  const { t, lang } = useLang();
  const [rows, setRows] = useState<Patient[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [q, setQ] = useState("");
  const [modal, setModal] = useState(false);
  const [file, setFile] = useState<Full | null>(null);
  const [form, setForm] = useState<Partial<Full>>(empty);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setRows(await api<Patient[]>(`/api/patients?q=${encodeURIComponent(q)}`));
  }, [q]);

  useEffect(() => {
    const tm = setTimeout(load, 250);
    return () => clearTimeout(tm);
  }, [load]);
  useEffect(() => {
    api<Doctor[]>("/api/doctors").then(setDoctors).catch(() => {});
  }, []);

  function openNew() {
    setForm(empty);
    setModal(true);
  }
  function openEdit(p: Patient) {
    api<Full>(`/api/patients/${p.id}`).then((full) => {
      setForm(full);
      setModal(true);
    });
  }
  async function save() {
    setLoading(true);
    try {
      if (form.id) {
        await api(`/api/patients/${form.id}`, { method: "PUT", body: JSON.stringify(form) });
      } else {
        await api("/api/patients", { method: "POST", body: JSON.stringify(form) });
      }
      setModal(false);
      await load();
    } finally {
      setLoading(false);
    }
  }
  async function del(id: number) {
    if (!confirm(t("confirmDelete"))) return;
    await api(`/api/patients/${id}`, { method: "DELETE" });
    await load();
  }
  function openFile(p: Patient) {
    api<Full>(`/api/patients/${p.id}`).then(setFile);
  }

  const set = (k: keyof Full, v: unknown) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <div>
      <PageHeader
        title={t("patients")}
        icon={<PatientIcon className="h-6 w-6" />}
        action={<AddButton label={t("add")} onClick={openNew} />}
      />
      <div className="mb-4">
        <SearchBar value={q} onChange={setQ} placeholder={t("search")} />
      </div>

      {rows.length === 0 ? (
        <Empty text={t("noData")} />
      ) : (
        <Table
          head={
            <>
              <Th>{t("fileNumber")}</Th>
              <Th>{t("name")}</Th>
              <Th>{t("gender")}</Th>
              <Th>{t("age")}</Th>
              <Th>{t("phone")}</Th>
              <Th>{t("doctor")}</Th>
              <Th>{t("status")}</Th>
              <Th>{t("actions")}</Th>
            </>
          }
        >
          {rows.map((p) => (
            <tr key={p.id} className="hover:bg-slate-50">
              <Td className="font-mono text-xs">{p.fileNumber}</Td>
              <Td className="font-semibold text-slate-700">{p.name}</Td>
              <Td>{t(p.gender as TKey)}</Td>
              <Td>{calcAge(p.birthDate) ?? "-"}</Td>
              <Td dir="ltr" className="text-start">{p.phone ?? "-"}</Td>
              <Td>{p.doctorName ?? "-"}</Td>
              <Td>
                <Badge color={p.status === "active" ? "green" : "slate"}>
                  {t(p.status === "active" ? "active" : "inactive")}
                </Badge>
              </Td>
              <Td>
                <div className="flex gap-1">
                  <IconBtn onClick={() => openFile(p)} title={t("medicalFile")} tone="sky">
                    <XrayIcon className="h-4 w-4" />
                  </IconBtn>
                  <IconBtn onClick={() => openEdit(p)} title={t("edit")} tone="slate">
                    <EditIcon className="h-4 w-4" />
                  </IconBtn>
                  <IconBtn onClick={() => del(p.id)} title={t("delete")} tone="red">
                    <TrashIcon className="h-4 w-4" />
                  </IconBtn>
                </div>
              </Td>
            </tr>
          ))}
        </Table>
      )}

      {/* Add/Edit modal */}
      <Modal open={modal} onClose={() => setModal(false)} title={form.id ? t("edit") : t("add")} wide>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label={t("name")}><Input value={form.name ?? ""} onChange={(e) => set("name", e.target.value)} /></Field>
          <Field label={t("phone")}><Input dir="ltr" value={form.phone ?? ""} onChange={(e) => set("phone", e.target.value)} /></Field>
          <Field label={t("gender")}>
            <Select value={form.gender ?? "male"} onChange={(e) => set("gender", e.target.value)}>
              <option value="male">{t("male")}</option>
              <option value="female">{t("female")}</option>
            </Select>
          </Field>
          <Field label={t("birthDate")}><Input type="date" value={form.birthDate ?? ""} onChange={(e) => set("birthDate", e.target.value)} /></Field>
          <Field label={t("email")}><Input dir="ltr" value={form.email ?? ""} onChange={(e) => set("email", e.target.value)} /></Field>
          <Field label={t("occupation")}><Input value={form.occupation ?? ""} onChange={(e) => set("occupation", e.target.value)} /></Field>
          <Field label={t("maritalStatus")}><Input value={form.maritalStatus ?? ""} onChange={(e) => set("maritalStatus", e.target.value)} /></Field>
          <Field label={t("doctor")}>
            <Select value={form.doctorId ?? ""} onChange={(e) => set("doctorId", e.target.value)}>
              <option value="">-</option>
              {doctors.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </Select>
          </Field>
          <div className="sm:col-span-2"><Field label={t("address")}><Input value={form.address ?? ""} onChange={(e) => set("address", e.target.value)} /></Field></div>
          <Field label={t("allergies")}><Input value={form.allergies ?? ""} onChange={(e) => set("allergies", e.target.value)} /></Field>
          <Field label={t("chronicDiseases")}><Input value={form.chronicDiseases ?? ""} onChange={(e) => set("chronicDiseases", e.target.value)} /></Field>
          <Field label={t("bloodPressure")}><Input value={form.bloodPressure ?? ""} onChange={(e) => set("bloodPressure", e.target.value)} /></Field>
          <Field label={t("bloodSugar")}><Input value={form.bloodSugar ?? ""} onChange={(e) => set("bloodSugar", e.target.value)} /></Field>
          <div className="sm:col-span-2"><Field label={t("medicalHistory")}><Textarea rows={2} value={form.medicalHistory ?? ""} onChange={(e) => set("medicalHistory", e.target.value)} /></Field></div>
          <div className="sm:col-span-2"><Field label={t("notes")}><Textarea rows={2} value={form.notes ?? ""} onChange={(e) => set("notes", e.target.value)} /></Field></div>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <Btn variant="ghost" onClick={() => setModal(false)}>{t("cancel")}</Btn>
          <Btn onClick={save} disabled={loading || !form.name}>{t("save")}</Btn>
        </div>
      </Modal>

      {/* Medical file modal */}
      {file && <MedicalFileModal patient={file} onClose={() => setFile(null)} />}
    </div>
  );
}

function MedicalFileModal({ patient, onClose }: { patient: Full; onClose: () => void }) {
  const { t, lang } = useLang();
  const [tab, setTab] = useState<"info" | "chart">("info");
  return (
    <Modal open onClose={onClose} title={`${t("medicalFile")} — ${patient.name}`} wide>
      <div className="mb-4 flex gap-2">
        <TabBtn active={tab === "info"} onClick={() => setTab("info")}>{t("medicalHistory")}</TabBtn>
        <TabBtn active={tab === "chart"} onClick={() => setTab("chart")}>{t("odontogram")}</TabBtn>
      </div>
      {tab === "info" ? (
        <div className="grid gap-3 sm:grid-cols-2">
          <Info label={t("fileNumber")} value={patient.fileNumber} />
          <Info label={t("age")} value={String(calcAge(patient.birthDate) ?? "-")} />
          <Info label={t("phone")} value={patient.phone ?? "-"} />
          <Info label={t("birthDate")} value={fmtDate(patient.birthDate, lang)} />
          <Info label={t("allergies")} value={patient.allergies ?? "-"} />
          <Info label={t("chronicDiseases")} value={patient.chronicDiseases ?? "-"} />
          <Info label={t("bloodPressure")} value={patient.bloodPressure ?? "-"} />
          <Info label={t("bloodSugar")} value={patient.bloodSugar ?? "-"} />
          <div className="sm:col-span-2"><Info label={t("medicalHistory")} value={patient.medicalHistory ?? "-"} /></div>
          <div className="sm:col-span-2"><Info label={t("treatmentPlan")} value={patient.treatmentPlan ?? "-"} /></div>
        </div>
      ) : (
        <Odontogram patientId={patient.id} />
      )}
    </Modal>
  );
}

const CONDITIONS = [
  "healthy", "extraction", "filling", "root_canal", "prosthesis",
  "implant", "crown", "cleaning", "whitening", "orthodontics",
] as const;
const COND_COLOR: Record<string, string> = {
  healthy: "#e2e8f0", extraction: "#ef4444", filling: "#3b82f6", root_canal: "#f59e0b",
  prosthesis: "#8b5cf6", implant: "#10b981", crown: "#eab308", cleaning: "#06b6d4",
  whitening: "#ec4899", orthodontics: "#6366f1",
};

const UPPER_R = [18, 17, 16, 15, 14, 13, 12, 11];
const UPPER_L = [21, 22, 23, 24, 25, 26, 27, 28];
const LOWER_R = [48, 47, 46, 45, 44, 43, 42, 41];
const LOWER_L = [31, 32, 33, 34, 35, 36, 37, 38];

function Odontogram({ patientId }: { patientId: number }) {
  const { t } = useLang();
  const [records, setRecords] = useState<Record<number, string>>({});
  const [active, setActive] = useState<string>("filling");

  const load = useCallback(() => {
    api<{ toothNumber: number; condition: string }[]>(`/api/patients/${patientId}/teeth`).then((r) => {
      const map: Record<number, string> = {};
      r.forEach((x) => (map[x.toothNumber] = x.condition));
      setRecords(map);
    });
  }, [patientId]);
  useEffect(load, [load]);

  async function setTooth(n: number) {
    const condition = records[n] === active ? "healthy" : active;
    setRecords((m) => ({ ...m, [n]: condition }));
    await api(`/api/patients/${patientId}/teeth`, {
      method: "POST",
      body: JSON.stringify({ toothNumber: n, condition }),
    });
  }

  const Tooth = ({ n }: { n: number }) => {
    const cond = records[n] ?? "healthy";
    return (
      <button
        onClick={() => setTooth(n)}
        title={`${n} — ${t(cond as TKey)}`}
        className="flex flex-col items-center gap-0.5 transition hover:scale-110"
      >
        <ToothIcon className="h-7 w-7" style={{ color: COND_COLOR[cond] }} />
        <span className="text-[9px] font-semibold text-slate-500">{n}</span>
      </button>
    );
  };

  return (
    <div>
      <p className="mb-3 text-center text-xs text-slate-500">{t("toothChartHint")}</p>
      <div className="mb-4 flex flex-wrap justify-center gap-1.5">
        {CONDITIONS.map((c) => (
          <button
            key={c}
            onClick={() => setActive(c)}
            className={`flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold transition ${
              active === c ? "ring-2 ring-sky-400" : ""
            }`}
            style={{ background: `${COND_COLOR[c]}22`, color: COND_COLOR[c] === "#e2e8f0" ? "#64748b" : COND_COLOR[c] }}
          >
            <span className="h-2.5 w-2.5 rounded-full" style={{ background: COND_COLOR[c] }} />
            {t(c as TKey)}
          </button>
        ))}
      </div>
      <div className="space-y-4 rounded-2xl bg-slate-50 p-4">
        <div className="flex justify-center gap-4">
          <div className="flex gap-1 border-e-2 border-slate-300 pe-3">{UPPER_R.map((n) => <Tooth key={n} n={n} />)}</div>
          <div className="flex gap-1">{UPPER_L.map((n) => <Tooth key={n} n={n} />)}</div>
        </div>
        <div className="flex justify-center gap-4 border-t-2 border-dashed border-slate-300 pt-4">
          <div className="flex gap-1 border-e-2 border-slate-300 pe-3">{LOWER_R.map((n) => <Tooth key={n} n={n} />)}</div>
          <div className="flex gap-1">{LOWER_L.map((n) => <Tooth key={n} n={n} />)}</div>
        </div>
      </div>
    </div>
  );
}

/* small helpers */
function Th({ children }: { children: React.ReactNode }) {
  return <th className="px-4 py-3 text-start font-semibold">{children}</th>;
}
function Td({ children, className = "", dir }: { children: React.ReactNode; className?: string; dir?: string }) {
  return <td dir={dir} className={`px-4 py-3 text-slate-600 ${className}`}>{children}</td>;
}
function IconBtn({ children, onClick, title, tone }: { children: React.ReactNode; onClick: () => void; title: string; tone: "sky" | "slate" | "red" }) {
  const map = { sky: "text-sky-600 hover:bg-sky-50", slate: "text-slate-500 hover:bg-slate-100", red: "text-rose-500 hover:bg-rose-50" };
  return <button title={title} onClick={onClick} className={`rounded-lg p-1.5 ${map[tone]}`}>{children}</button>;
}
function TabBtn({ children, active, onClick }: { children: React.ReactNode; active: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} className={`rounded-xl px-4 py-2 text-sm font-semibold ${active ? "bg-sky-600 text-white" : "bg-slate-100 text-slate-600"}`}>
      {children}
    </button>
  );
}
function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-slate-50 px-3 py-2">
      <p className="text-xs font-semibold text-slate-400">{label}</p>
      <p className="text-sm font-medium text-slate-700">{value}</p>
    </div>
  );
}

export { Th, Td, IconBtn };
