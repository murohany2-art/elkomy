"use client";
import { useEffect, useState } from "react";
import { useLang } from "../lang-provider";
import { api, money } from "@/lib/format";
import { PageHeader, Card, Empty, Btn } from "../ui";
import { StatCard, BarChart } from "../charts";
import { ChartIcon, MoneyIcon, PatientIcon } from "../icons";

type Rep = {
  summary: { revenue: number; expenses: number; profit: number; patients: number };
  monthly: { month: string; revenue: number }[];
  topServices: { name: string | null; count: number; revenue: number }[];
  byDoctor: { name: string | null; revenue: number; count: number }[];
};

export function ReportsView() {
  const { t, lang } = useLang();
  const [r, setR] = useState<Rep | null>(null);
  useEffect(() => { api<Rep>("/api/reports").then(setR); }, []);
  if (!r) return <p className="text-slate-400">{t("loading")}</p>;

  const monthShort = (m: string) => new Date(m + "-01").toLocaleDateString(lang === "ar" ? "ar-EG" : "en", { month: "short" });

  return (
    <div>
      <PageHeader title={t("reports")} icon={<ChartIcon className="h-6 w-6" />}
        action={<Btn variant="soft" onClick={() => window.print()}>{t("print")}</Btn>} />
      <div className="mb-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label={t("income")} value={money(r.summary.revenue, "EGP", lang)} icon={<MoneyIcon className="h-6 w-6" />} tone="emerald" />
        <StatCard label={t("expenses")} value={money(r.summary.expenses, "EGP", lang)} icon={<MoneyIcon className="h-6 w-6" />} tone="rose" />
        <StatCard label={t("profit")} value={money(r.summary.profit, "EGP", lang)} icon={<ChartIcon className="h-6 w-6" />} tone="sky" />
        <StatCard label={t("totalPatients")} value={r.summary.patients} icon={<PatientIcon className="h-6 w-6" />} tone="indigo" />
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <h3 className="mb-3 font-bold text-slate-700">{t("revenueReport")}</h3>
          <BarChart data={r.monthly.map((m) => ({ label: monthShort(m.month), value: Number(m.revenue) }))} color="#10b981" />
        </Card>
        <Card>
          <h3 className="mb-3 font-bold text-slate-700">{t("topServices")}</h3>
          {r.topServices.length === 0 ? <Empty text={t("noData")} /> : (
            <ul className="space-y-2">
              {r.topServices.map((s, i) => (
                <li key={i} className="flex items-center justify-between rounded-xl bg-slate-50 px-3 py-2">
                  <span className="text-sm font-semibold text-slate-700">{s.name ?? "-"}</span>
                  <span className="text-sm font-bold text-sky-700">{money(s.revenue, "EGP", lang)}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>
        <Card className="lg:col-span-2">
          <h3 className="mb-3 font-bold text-slate-700">{t("doctors")}</h3>
          {r.byDoctor.length === 0 ? <Empty text={t("noData")} /> : (
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {r.byDoctor.map((d, i) => (
                <div key={i} className="flex items-center justify-between rounded-xl bg-slate-50 px-3 py-2">
                  <span className="text-sm font-semibold text-slate-700">{d.name ?? "-"}</span>
                  <span className="text-sm font-bold text-emerald-600">{money(d.revenue, "EGP", lang)}</span>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
