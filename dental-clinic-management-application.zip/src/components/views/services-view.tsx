"use client";
import { useEffect, useState, useCallback } from "react";
import { useLang } from "../lang-provider";
import { api, money } from "@/lib/format";
import { PageHeader, AddButton, Table, Modal, Field, Input, Btn, Empty } from "../ui";
import { Th, Td, IconBtn } from "./patients-view";
import { ToolIcon, EditIcon, TrashIcon } from "../icons";

type Svc = { id: number; name: string; category: string | null; price: string; durationMinutes: number | null };

export function ServicesView() {
  const { t, lang } = useLang();
  const [rows, setRows] = useState<Svc[]>([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState<Partial<Svc>>({});

  const load = useCallback(() => api<Svc[]>("/api/services").then(setRows), []);
  useEffect(() => { load(); }, [load]);

  async function save() {
    const url = form.id ? `/api/services/${form.id}` : "/api/services";
    await api(url, { method: form.id ? "PUT" : "POST", body: JSON.stringify(form) });
    setModal(false); setForm({}); load();
  }
  async function del(id: number) {
    if (!confirm(t("confirmDelete"))) return;
    await api(`/api/services/${id}`, { method: "DELETE" }); load();
  }

  return (
    <div>
      <PageHeader title={t("services")} icon={<ToolIcon className="h-6 w-6" />}
        action={<AddButton label={t("add")} onClick={() => { setForm({}); setModal(true); }} />} />
      {rows.length === 0 ? <Empty text={t("noData")} /> : (
        <Table head={<><Th>{t("name")}</Th><Th>{t("category")}</Th><Th>{t("price")}</Th><Th>{t("duration")}</Th><Th>{t("actions")}</Th></>}>
          {rows.map((s) => (
            <tr key={s.id} className="hover:bg-slate-50">
              <Td className="font-semibold text-slate-700">{s.name}</Td>
              <Td>{s.category ?? "-"}</Td>
              <Td className="font-bold text-sky-700">{money(s.price, "EGP", lang)}</Td>
              <Td>{s.durationMinutes} {t("duration").includes("min") ? "min" : "د"}</Td>
              <Td>
                <div className="flex gap-1">
                  <IconBtn onClick={() => { setForm(s); setModal(true); }} title={t("edit")} tone="slate"><EditIcon className="h-4 w-4" /></IconBtn>
                  <IconBtn onClick={() => del(s.id)} title={t("delete")} tone="red"><TrashIcon className="h-4 w-4" /></IconBtn>
                </div>
              </Td>
            </tr>
          ))}
        </Table>
      )}
      <Modal open={modal} onClose={() => setModal(false)} title={form.id ? t("edit") : t("add")}>
        <div className="space-y-3">
          <Field label={t("name")}><Input value={form.name ?? ""} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label={t("category")}><Input value={form.category ?? ""} onChange={(e) => setForm({ ...form, category: e.target.value })} /></Field>
          <Field label={t("price")}><Input type="number" value={form.price ?? ""} onChange={(e) => setForm({ ...form, price: e.target.value })} /></Field>
          <Field label={t("duration")}><Input type="number" value={form.durationMinutes ?? 30} onChange={(e) => setForm({ ...form, durationMinutes: Number(e.target.value) })} /></Field>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <Btn variant="ghost" onClick={() => setModal(false)}>{t("cancel")}</Btn>
          <Btn onClick={save} disabled={!form.name}>{t("save")}</Btn>
        </div>
      </Modal>
    </div>
  );
}
