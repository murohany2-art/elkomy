"use client";
import { useEffect, useState } from "react";
import { useLang } from "../lang-provider";
import { api } from "@/lib/format";
import { PageHeader, Card, Field, Input, Select, Btn } from "../ui";
import { SettingsIcon, BackupIcon, ShieldIcon, GlobeIcon } from "../icons";

export function SettingsView() {
  const { t, lang, setLang } = useLang();
  const [s, setS] = useState<Record<string, string>>({});
  const [saved, setSaved] = useState(false);
  const [backupInfo, setBackupInfo] = useState("");

  useEffect(() => { api<Record<string, string>>("/api/settings").then(setS); }, []);

  async function save() {
    await api("/api/settings", { method: "PUT", body: JSON.stringify(s) });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }
  async function backup() {
    const res = await api<{ filename: string; encrypted: string; stats: Record<string, number> }>("/api/backup");
    const blob = new Blob([res.encrypted], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = res.filename; a.click();
    URL.revokeObjectURL(url);
    setBackupInfo(Object.entries(res.stats).map(([k, v]) => `${k}: ${v}`).join(" · "));
  }
  const set = (k: string, v: string) => setS({ ...s, [k]: v });

  return (
    <div>
      <PageHeader title={t("settings")} icon={<SettingsIcon className="h-6 w-6" />} />
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <h3 className="mb-4 flex items-center gap-2 font-bold text-slate-700"><SettingsIcon className="h-5 w-5 text-sky-600" /> {t("clinicName")}</h3>
          <div className="space-y-3">
            <Field label={t("clinicName")}><Input value={s.clinic_name ?? ""} onChange={(e) => set("clinic_name", e.target.value)} /></Field>
            <Field label={t("phone")}><Input dir="ltr" value={s.clinic_phone ?? ""} onChange={(e) => set("clinic_phone", e.target.value)} /></Field>
            <Field label={t("address")}><Input value={s.clinic_address ?? ""} onChange={(e) => set("clinic_address", e.target.value)} /></Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("currency")}><Input value={s.currency ?? "EGP"} onChange={(e) => set("currency", e.target.value)} /></Field>
              <Field label={t("taxRate")}><Input type="number" value={s.tax_rate ?? "14"} onChange={(e) => set("tax_rate", e.target.value)} /></Field>
            </div>
            <Btn onClick={save}>{saved ? t("settingsSaved") : t("saveSettings")}</Btn>
          </div>
        </Card>

        <div className="space-y-4">
          <Card>
            <h3 className="mb-3 flex items-center gap-2 font-bold text-slate-700"><GlobeIcon className="h-5 w-5 text-sky-600" /> {t("language")}</h3>
            <Select value={lang} onChange={(e) => setLang(e.target.value as "ar" | "en")}>
              <option value="ar">العربية (RTL)</option>
              <option value="en">English (LTR)</option>
            </Select>
          </Card>
          <Card>
            <h3 className="mb-3 flex items-center gap-2 font-bold text-slate-700"><BackupIcon className="h-5 w-5 text-emerald-600" /> {t("backup")}</h3>
            <p className="mb-3 text-xs text-slate-500">تشفير AES-256 · Encrypted backup</p>
            <Btn variant="success" onClick={backup}>{t("createBackup")}</Btn>
            {backupInfo && <p className="mt-2 text-xs text-slate-500">{backupInfo}</p>}
          </Card>
          <Card>
            <h3 className="mb-3 flex items-center gap-2 font-bold text-slate-700"><ShieldIcon className="h-5 w-5 text-indigo-600" /> {t("activation")}</h3>
            <p className="text-sm text-emerald-600">✓ {t("activationSuccess")}</p>
          </Card>
        </div>
      </div>
    </div>
  );
}
