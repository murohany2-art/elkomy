"use client";
import { useEffect, useState, useCallback } from "react";
import { useLang } from "../lang-provider";
import { api, fmtDateTime } from "@/lib/format";
import { PageHeader, AddButton, Table, Modal, Field, Input, Select, Btn, Badge, Empty } from "../ui";
import { Th, Td, IconBtn } from "./patients-view";
import { UsersIcon, EditIcon, TrashIcon } from "../icons";
import type { TKey } from "@/lib/i18n";

type U = { id: number; username: string; fullName: string; role: string; email: string | null; phone: string | null; isActive: boolean; lastLoginAt: string | null };
const ROLES = ["admin", "doctor", "reception", "accountant", "assistant"];

export function UsersView() {
  const { t } = useLang();
  const [rows, setRows] = useState<U[]>([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState<Partial<U> & { password?: string }>({});

  const load = useCallback(() => api<U[]>("/api/users").then(setRows).catch(() => {}), []);
  useEffect(() => { load(); }, [load]);

  async function save() {
    const url = form.id ? `/api/users/${form.id}` : "/api/users";
    await api(url, { method: form.id ? "PUT" : "POST", body: JSON.stringify(form) });
    setModal(false); setForm({}); load();
  }
  async function del(id: number) {
    if (!confirm(t("confirmDelete"))) return;
    await api(`/api/users/${id}`, { method: "DELETE" }); load();
  }

  return (
    <div>
      <PageHeader title={t("users")} icon={<UsersIcon className="h-6 w-6" />}
        action={<AddButton label={t("add")} onClick={() => { setForm({ role: "reception", isActive: true }); setModal(true); }} />} />
      {rows.length === 0 ? <Empty text={t("noData")} /> : (
        <Table head={<><Th>{t("username")}</Th><Th>{t("name")}</Th><Th>{t("role")}</Th><Th>{t("status")}</Th><Th>Last login</Th><Th>{t("actions")}</Th></>}>
          {rows.map((u) => (
            <tr key={u.id} className="hover:bg-slate-50">
              <Td className="font-mono text-xs">{u.username}</Td>
              <Td className="font-semibold text-slate-700">{u.fullName}</Td>
              <Td><Badge color="sky">{t(u.role as TKey)}</Badge></Td>
              <Td><Badge color={u.isActive ? "green" : "slate"}>{t(u.isActive ? "active" : "inactive")}</Badge></Td>
              <Td className="text-xs">{u.lastLoginAt ? fmtDateTime(u.lastLoginAt) : "-"}</Td>
              <Td>
                <div className="flex gap-1">
                  <IconBtn onClick={() => { setForm({ ...u, password: "" }); setModal(true); }} title={t("edit")} tone="slate"><EditIcon className="h-4 w-4" /></IconBtn>
                  <IconBtn onClick={() => del(u.id)} title={t("delete")} tone="red"><TrashIcon className="h-4 w-4" /></IconBtn>
                </div>
              </Td>
            </tr>
          ))}
        </Table>
      )}
      <Modal open={modal} onClose={() => setModal(false)} title={form.id ? t("edit") : t("add")}>
        <div className="grid gap-3 sm:grid-cols-2">
          {!form.id && <Field label={t("username")}><Input value={form.username ?? ""} onChange={(e) => setForm({ ...form, username: e.target.value })} /></Field>}
          <Field label={t("name")}><Input value={form.fullName ?? ""} onChange={(e) => setForm({ ...form, fullName: e.target.value })} /></Field>
          <Field label={t("role")}>
            <Select value={form.role ?? "reception"} onChange={(e) => setForm({ ...form, role: e.target.value })}>
              {ROLES.map((r) => <option key={r} value={r}>{t(r as TKey)}</option>)}
            </Select>
          </Field>
          <Field label={t("password")}><Input type="password" value={form.password ?? ""} onChange={(e) => setForm({ ...form, password: e.target.value })} /></Field>
          <Field label={t("email")}><Input dir="ltr" value={form.email ?? ""} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
          <Field label={t("status")}>
            <Select value={form.isActive ? "1" : "0"} onChange={(e) => setForm({ ...form, isActive: e.target.value === "1" })}>
              <option value="1">{t("active")}</option>
              <option value="0">{t("inactive")}</option>
            </Select>
          </Field>
        </div>
        <div className="mt-5 flex justify-end gap-2">
          <Btn variant="ghost" onClick={() => setModal(false)}>{t("cancel")}</Btn>
          <Btn onClick={save} disabled={!form.fullName || (!form.id && (!form.username || !form.password))}>{t("save")}</Btn>
        </div>
      </Modal>
    </div>
  );
}
