/**
 * Dental Clinic Pro - Database Schema (Drizzle ORM / PostgreSQL)
 * -------------------------------------------------------------
 * Defines all tables, relationships, foreign keys, and indexes for the
 * clinic management system. Mirrors the modules requested: users/roles,
 * patients, doctors, appointments, services, invoices, payments, inventory,
 * medical records, odontogram (tooth chart), accounting, settings, licensing,
 * and audit logging.
 */
import {
  pgTable,
  serial,
  text,
  integer,
  timestamp,
  numeric,
  boolean,
  date,
  index,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* Users & Security                                                    */
/* ------------------------------------------------------------------ */
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    username: text("username").notNull().unique(),
    fullName: text("full_name").notNull(),
    passwordHash: text("password_hash").notNull(),
    // admin | doctor | reception | accountant | assistant
    role: text("role").notNull().default("reception"),
    email: text("email"),
    phone: text("phone"),
    isActive: boolean("is_active").notNull().default(true),
    lastLoginAt: timestamp("last_login_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    usernameIdx: index("users_username_idx").on(t.username),
    roleIdx: index("users_role_idx").on(t.role),
  }),
);

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").references(() => users.id, { onDelete: "set null" }),
    username: text("username"),
    action: text("action").notNull(),
    entity: text("entity"),
    details: text("details"),
    ip: text("ip"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    userIdx: index("audit_user_idx").on(t.userId),
    createdIdx: index("audit_created_idx").on(t.createdAt),
  }),
);

/* ------------------------------------------------------------------ */
/* Doctors                                                             */
/* ------------------------------------------------------------------ */
export const doctors = pgTable(
  "doctors",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    specialty: text("specialty"),
    phone: text("phone"),
    email: text("email"),
    // commission percentage on treatments
    commissionRate: numeric("commission_rate", { precision: 5, scale: 2 }).default("0"),
    salary: numeric("salary", { precision: 12, scale: 2 }).default("0"),
    schedule: text("schedule"),
    photoUrl: text("photo_url"),
    color: text("color").default("#0ea5e9"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    nameIdx: index("doctors_name_idx").on(t.name),
  }),
);

/* ------------------------------------------------------------------ */
/* Patients                                                            */
/* ------------------------------------------------------------------ */
export const patients = pgTable(
  "patients",
  {
    id: serial("id").primaryKey(),
    fileNumber: text("file_number").notNull().unique(),
    name: text("name").notNull(),
    gender: text("gender").default("male"), // male | female
    birthDate: date("birth_date"),
    phone: text("phone"),
    address: text("address"),
    email: text("email"),
    occupation: text("occupation"),
    maritalStatus: text("marital_status"),
    notes: text("notes"),
    photoUrl: text("photo_url"),
    status: text("status").default("active"), // active | inactive
    doctorId: integer("doctor_id").references(() => doctors.id, { onDelete: "set null" }),
    // Medical record fields
    medicalHistory: text("medical_history"),
    medications: text("medications"),
    allergies: text("allergies"),
    chronicDiseases: text("chronic_diseases"),
    bloodPressure: text("blood_pressure"),
    bloodSugar: text("blood_sugar"),
    treatmentPlan: text("treatment_plan"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    nameIdx: index("patients_name_idx").on(t.name),
    fileIdx: index("patients_file_idx").on(t.fileNumber),
    phoneIdx: index("patients_phone_idx").on(t.phone),
  }),
);

/* Odontogram: state per tooth per patient */
export const toothRecords = pgTable(
  "tooth_records",
  {
    id: serial("id").primaryKey(),
    patientId: integer("patient_id")
      .notNull()
      .references(() => patients.id, { onDelete: "cascade" }),
    toothNumber: integer("tooth_number").notNull(), // FDI numbering 11-48
    // extraction|filling|root_canal|prosthesis|implant|crown|cleaning|whitening|orthodontics|healthy
    condition: text("condition").notNull().default("healthy"),
    notes: text("notes"),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => ({
    patientIdx: index("tooth_patient_idx").on(t.patientId),
  }),
);

/* ------------------------------------------------------------------ */
/* Services                                                            */
/* ------------------------------------------------------------------ */
export const services = pgTable(
  "services",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    category: text("category"),
    price: numeric("price", { precision: 12, scale: 2 }).notNull().default("0"),
    durationMinutes: integer("duration_minutes").default(30),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    nameIdx: index("services_name_idx").on(t.name),
  }),
);

/* ------------------------------------------------------------------ */
/* Appointments                                                        */
/* ------------------------------------------------------------------ */
export const appointments = pgTable(
  "appointments",
  {
    id: serial("id").primaryKey(),
    patientId: integer("patient_id").references(() => patients.id, { onDelete: "cascade" }),
    doctorId: integer("doctor_id").references(() => doctors.id, { onDelete: "set null" }),
    serviceId: integer("service_id").references(() => services.id, { onDelete: "set null" }),
    startTime: timestamp("start_time").notNull(),
    endTime: timestamp("end_time"),
    // scheduled | confirmed | completed | cancelled | no_show
    status: text("status").notNull().default("scheduled"),
    notes: text("notes"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    startIdx: index("appt_start_idx").on(t.startTime),
    patientIdx: index("appt_patient_idx").on(t.patientId),
    doctorIdx: index("appt_doctor_idx").on(t.doctorId),
  }),
);

/* ------------------------------------------------------------------ */
/* Invoices & Payments                                                 */
/* ------------------------------------------------------------------ */
export const invoices = pgTable(
  "invoices",
  {
    id: serial("id").primaryKey(),
    invoiceNumber: text("invoice_number").notNull().unique(),
    patientId: integer("patient_id").references(() => patients.id, { onDelete: "set null" }),
    doctorId: integer("doctor_id").references(() => doctors.id, { onDelete: "set null" }),
    subtotal: numeric("subtotal", { precision: 12, scale: 2 }).notNull().default("0"),
    discount: numeric("discount", { precision: 12, scale: 2 }).notNull().default("0"),
    tax: numeric("tax", { precision: 12, scale: 2 }).notNull().default("0"),
    total: numeric("total", { precision: 12, scale: 2 }).notNull().default("0"),
    paid: numeric("paid", { precision: 12, scale: 2 }).notNull().default("0"),
    // cash | card | transfer | wallet
    paymentMethod: text("payment_method").default("cash"),
    status: text("status").notNull().default("unpaid"), // paid | partial | unpaid
    notes: text("notes"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    patientIdx: index("inv_patient_idx").on(t.patientId),
    createdIdx: index("inv_created_idx").on(t.createdAt),
    numberIdx: index("inv_number_idx").on(t.invoiceNumber),
  }),
);

export const invoiceItems = pgTable(
  "invoice_items",
  {
    id: serial("id").primaryKey(),
    invoiceId: integer("invoice_id")
      .notNull()
      .references(() => invoices.id, { onDelete: "cascade" }),
    serviceId: integer("service_id").references(() => services.id, { onDelete: "set null" }),
    description: text("description").notNull(),
    quantity: integer("quantity").notNull().default(1),
    unitPrice: numeric("unit_price", { precision: 12, scale: 2 }).notNull().default("0"),
    total: numeric("total", { precision: 12, scale: 2 }).notNull().default("0"),
  },
  (t) => ({
    invoiceIdx: index("invitem_invoice_idx").on(t.invoiceId),
  }),
);

/* ------------------------------------------------------------------ */
/* Inventory                                                           */
/* ------------------------------------------------------------------ */
export const inventory = pgTable(
  "inventory",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull(),
    category: text("category"), // medicine | material | tool
    barcode: text("barcode"),
    quantity: integer("quantity").notNull().default(0),
    minQuantity: integer("min_quantity").notNull().default(5),
    unitPrice: numeric("unit_price", { precision: 12, scale: 2 }).default("0"),
    supplier: text("supplier"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    nameIdx: index("inv_item_name_idx").on(t.name),
  }),
);

/* ------------------------------------------------------------------ */
/* Accounting: expenses & transactions                                */
/* ------------------------------------------------------------------ */
export const transactions = pgTable(
  "transactions",
  {
    id: serial("id").primaryKey(),
    type: text("type").notNull().default("expense"), // income | expense
    category: text("category"),
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull().default("0"),
    description: text("description"),
    party: text("party"), // supplier/customer name
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    typeIdx: index("tx_type_idx").on(t.type),
    createdIdx: index("tx_created_idx").on(t.createdAt),
  }),
);

/* ------------------------------------------------------------------ */
/* Settings & Licensing                                                */
/* ------------------------------------------------------------------ */
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value"),
});

export const licenses = pgTable("licenses", {
  id: serial("id").primaryKey(),
  serialKey: text("serial_key").notNull().unique(),
  // encrypted activation payload
  activationData: text("activation_data"),
  isActivated: boolean("is_activated").notNull().default(false),
  activatedAt: timestamp("activated_at"),
});

/* Types */
export type User = typeof users.$inferSelect;
export type Patient = typeof patients.$inferSelect;
export type Doctor = typeof doctors.$inferSelect;
export type Service = typeof services.$inferSelect;
export type Appointment = typeof appointments.$inferSelect;
export type Invoice = typeof invoices.$inferSelect;
export type InventoryItem = typeof inventory.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type ToothRecord = typeof toothRecords.$inferSelect;
