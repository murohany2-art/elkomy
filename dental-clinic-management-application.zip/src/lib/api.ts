/** Shared helpers for API route handlers. */
import { ensureSeeded } from "./seed";
import { getSession, type SessionUser } from "./auth";

let ready = false;

/** Ensures the database is seeded once per process. */
export async function ready$() {
  if (!ready) {
    await ensureSeeded();
    ready = true;
  }
}

/** Guard used by protected routes. Throws a Response on failure. */
export async function requireUser(): Promise<SessionUser> {
  const user = await getSession();
  if (!user) {
    throw Response.json({ error: "unauthorized" }, { status: 401 });
  }
  return user;
}

export function ok(data: unknown) {
  return Response.json(data);
}

export function bad(message: string, status = 400) {
  return Response.json({ error: message }, { status });
}

/** Wraps a handler with seeding + centralized error handling. */
export function handler(
  fn: (req: Request, ctx: { params: Promise<Record<string, string>> }) => Promise<Response>,
) {
  return async (req: Request, ctx: { params: Promise<Record<string, string>> }) => {
    try {
      await ready$();
      return await fn(req, ctx);
    } catch (e) {
      if (e instanceof Response) return e;
      console.error(e);
      return Response.json({ error: "server_error" }, { status: 500 });
    }
  };
}
