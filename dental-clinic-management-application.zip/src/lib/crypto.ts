/**
 * Encryption utilities using Node's built-in crypto (AES-256-GCM).
 * Used for encrypting license/activation data and signing session tokens.
 */
import crypto from "crypto";

const SECRET =
  process.env.APP_SECRET ?? "dental-clinic-pro-default-secret-key-change-me";

// Derive a 32-byte key from the secret
const KEY = crypto.createHash("sha256").update(SECRET).digest();

/** Encrypt a UTF-8 string, returns base64 "iv:tag:cipher". */
export function encrypt(plain: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", KEY, iv);
  const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString("base64")}:${tag.toString("base64")}:${enc.toString("base64")}`;
}

/** Decrypt a value produced by {@link encrypt}. Returns null on failure. */
export function decrypt(payload: string): string | null {
  try {
    const [ivB64, tagB64, dataB64] = payload.split(":");
    const iv = Buffer.from(ivB64, "base64");
    const tag = Buffer.from(tagB64, "base64");
    const data = Buffer.from(dataB64, "base64");
    const decipher = crypto.createDecipheriv("aes-256-gcm", KEY, iv);
    decipher.setAuthTag(tag);
    const dec = Buffer.concat([decipher.update(data), decipher.final()]);
    return dec.toString("utf8");
  } catch {
    return null;
  }
}

/** Create an HMAC-SHA256 signature for arbitrary data. */
export function sign(data: string): string {
  return crypto.createHmac("sha256", KEY).update(data).digest("base64url");
}

/**
 * License validation. A valid serial follows the pattern
 * DCP-XXXX-XXXX-XXXX-XXXX where the last block is a checksum derived from the
 * first three blocks. This lets us validate serials offline and generate them.
 */
function checksumBlock(base: string): string {
  const h = crypto.createHash("sha256").update(base + SECRET).digest("hex");
  return h.slice(0, 4).toUpperCase();
}

export function generateSerial(): string {
  const rand = () =>
    crypto.randomBytes(2).toString("hex").toUpperCase().slice(0, 4);
  const a = rand();
  const b = rand();
  const c = rand();
  const chk = checksumBlock(`${a}${b}${c}`);
  return `DCP-${a}-${b}-${c}-${chk}`;
}

export function validateSerial(serial: string): boolean {
  const m = serial
    .trim()
    .toUpperCase()
    .match(/^DCP-([0-9A-F]{4})-([0-9A-F]{4})-([0-9A-F]{4})-([0-9A-F]{4})$/);
  if (!m) return false;
  const [, a, b, c, chk] = m;
  return checksumBlock(`${a}${b}${c}`) === chk;
}
