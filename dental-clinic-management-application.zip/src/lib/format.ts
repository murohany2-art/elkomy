/** Client-safe formatting helpers. */
export function money(v: unknown, currency = "EGP", lang = "ar") {
  const n = Number(v ?? 0);
  return new Intl.NumberFormat(lang === "ar" ? "ar-EG" : "en-US", {
    style: "currency",
    currency,
    maximumFractionDigits: 0,
  }).format(n);
}

export function num(v: unknown) {
  return Number(v ?? 0);
}

export function fmtDate(v: unknown, lang = "ar") {
  if (!v) return "-";
  const d = new Date(v as string);
  if (isNaN(d.getTime())) return "-";
  return d.toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

export function fmtDateTime(v: unknown, lang = "ar") {
  if (!v) return "-";
  const d = new Date(v as string);
  if (isNaN(d.getTime())) return "-";
  return d.toLocaleString(lang === "ar" ? "ar-EG" : "en-GB", {
    dateStyle: "short",
    timeStyle: "short",
  });
}

export function fmtTime(v: unknown, lang = "ar") {
  if (!v) return "-";
  const d = new Date(v as string);
  return d.toLocaleTimeString(lang === "ar" ? "ar-EG" : "en-GB", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function calcAge(birth: unknown): number | null {
  if (!birth) return null;
  const d = new Date(birth as string);
  if (isNaN(d.getTime())) return null;
  const diff = Date.now() - d.getTime();
  return Math.floor(diff / (365.25 * 24 * 3600 * 1000));
}

export async function api<T = unknown>(
  url: string,
  options?: RequestInit,
): Promise<T> {
  const res = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: "error" }));
    throw new Error(err.error || "request_failed");
  }
  return res.json();
}
