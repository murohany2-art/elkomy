/**
 * Idempotent database seeding. Creates a default admin, sample clinical data,
 * clinic settings and a demo license serial on first run.
 */
import { db } from "@/db";
import {
  users,
  doctors,
  patients,
  services,
  appointments,
  invoices,
  invoiceItems,
  inventory,
  transactions,
  settings,
  licenses,
} from "@/db/schema";
import { sql } from "drizzle-orm";
import { hashPassword } from "./auth";
import { generateSerial } from "./crypto";

let seedPromise: Promise<void> | null = null;

export function ensureSeeded(): Promise<void> {
  if (!seedPromise) seedPromise = runSeed();
  return seedPromise;
}

async function runSeed() {
  const existing = await db.select({ c: sql<number>`count(*)` }).from(users);
  if (Number(existing[0]?.c ?? 0) > 0) return;

  // --- Default users (one per role) ---
  const adminHash = await hashPassword("admin123");
  const commonHash = await hashPassword("123456");
  await db.insert(users).values([
    { username: "admin", fullName: "مدير النظام", role: "admin", passwordHash: adminHash, email: "admin@dentalpro.app" },
    { username: "doctor", fullName: "د. محمد أحمد", role: "doctor", passwordHash: commonHash },
    { username: "reception", fullName: "موظف الاستقبال", role: "reception", passwordHash: commonHash },
    { username: "accountant", fullName: "المحاسب", role: "accountant", passwordHash: commonHash },
    { username: "assistant", fullName: "مساعد الطبيب", role: "assistant", passwordHash: commonHash },
  ]);

  // --- Doctors ---
  const doctorRows = await db
    .insert(doctors)
    .values([
      { name: "د. محمد أحمد", specialty: "تقويم الأسنان", phone: "01000000001", email: "m.ahmed@clinic.app", commissionRate: "20", salary: "15000", color: "#0ea5e9" },
      { name: "د. سارة علي", specialty: "جراحة الفم", phone: "01000000002", email: "s.ali@clinic.app", commissionRate: "25", salary: "18000", color: "#6366f1" },
      { name: "د. خالد حسن", specialty: "علاج الجذور", phone: "01000000003", email: "k.hasan@clinic.app", commissionRate: "18", salary: "14000", color: "#14b8a6" },
    ])
    .returning({ id: doctors.id });

  // --- Services ---
  const serviceRows = await db
    .insert(services)
    .values([
      { name: "كشف وتشخيص", category: "فحص", price: "150", durationMinutes: 20 },
      { name: "حشو عادي", category: "حشوات", price: "400", durationMinutes: 45 },
      { name: "حشو عصب", category: "علاج الجذور", price: "1200", durationMinutes: 90 },
      { name: "خلع ضرس", category: "جراحة", price: "300", durationMinutes: 30 },
      { name: "تنظيف وتلميع", category: "وقاية", price: "350", durationMinutes: 40 },
      { name: "تبييض الأسنان", category: "تجميل", price: "2500", durationMinutes: 60 },
      { name: "تركيب تاج", category: "تركيبات", price: "3000", durationMinutes: 60 },
      { name: "زراعة سن", category: "زراعة", price: "8000", durationMinutes: 120 },
    ])
    .returning({ id: services.id, price: services.price });

  // --- Patients ---
  const patientSeed = [
    { fileNumber: "P-0001", name: "أحمد مصطفى", gender: "male", phone: "01111111111", occupation: "مهندس" },
    { fileNumber: "P-0002", name: "فاطمة الزهراء", gender: "female", phone: "01222222222", occupation: "معلمة" },
    { fileNumber: "P-0003", name: "يوسف كمال", gender: "male", phone: "01333333333", occupation: "محاسب" },
    { fileNumber: "P-0004", name: "نور حسين", gender: "female", phone: "01444444444", occupation: "طبيبة" },
    { fileNumber: "P-0005", name: "عمر شريف", gender: "male", phone: "01555555555", occupation: "طالب" },
    { fileNumber: "P-0006", name: "مريم سعيد", gender: "female", phone: "01666666666", occupation: "ربة منزل" },
  ];
  const patientRows = await db
    .insert(patients)
    .values(
      patientSeed.map((p, i) => ({
        ...p,
        doctorId: doctorRows[i % doctorRows.length].id,
        birthDate: `${1980 + i * 3}-0${(i % 9) + 1}-1${i}`,
        status: "active",
      })),
    )
    .returning({ id: patients.id });

  // --- Appointments (today + spread) ---
  const now = new Date();
  const apptValues = patientRows.map((p, i) => {
    const start = new Date(now);
    start.setHours(9 + i, 0, 0, 0);
    if (i > 2) start.setDate(start.getDate() + (i - 2));
    const end = new Date(start);
    end.setMinutes(end.getMinutes() + 45);
    return {
      patientId: p.id,
      doctorId: doctorRows[i % doctorRows.length].id,
      serviceId: serviceRows[i % serviceRows.length].id,
      startTime: start,
      endTime: end,
      status: (["scheduled", "confirmed", "completed", "scheduled", "confirmed", "completed"][i] ?? "scheduled"),
    };
  });
  await db.insert(appointments).values(apptValues);

  // --- Invoices with items ---
  let invCounter = 1;
  for (let i = 0; i < patientRows.length; i++) {
    const svc = serviceRows[i % serviceRows.length];
    const qty = 1;
    const unit = Number(svc.price);
    const subtotal = unit * qty;
    const tax = subtotal * 0.14;
    const total = subtotal + tax;
    const paid = i % 3 === 0 ? total : i % 3 === 1 ? total / 2 : 0;
    const createdAt = new Date(now);
    createdAt.setDate(createdAt.getDate() - i * 2);
    const [inv] = await db
      .insert(invoices)
      .values({
        invoiceNumber: `INV-${String(invCounter++).padStart(5, "0")}`,
        patientId: patientRows[i].id,
        doctorId: doctorRows[i % doctorRows.length].id,
        subtotal: subtotal.toFixed(2),
        discount: "0",
        tax: tax.toFixed(2),
        total: total.toFixed(2),
        paid: paid.toFixed(2),
        paymentMethod: (["cash", "card", "transfer", "wallet"][i % 4]),
        status: paid >= total ? "paid" : paid > 0 ? "partial" : "unpaid",
        createdAt,
      })
      .returning({ id: invoices.id });
    await db.insert(invoiceItems).values({
      invoiceId: inv.id,
      serviceId: svc.id,
      description: "خدمة علاجية",
      quantity: qty,
      unitPrice: unit.toFixed(2),
      total: subtotal.toFixed(2),
    });
  }

  // --- Inventory ---
  await db.insert(inventory).values([
    { name: "مخدر موضعي", category: "medicine", quantity: 40, minQuantity: 10, unitPrice: "25", supplier: "الشركة الطبية", barcode: "600100001" },
    { name: "مادة حشو ضوئي", category: "material", quantity: 8, minQuantity: 10, unitPrice: "300", supplier: "دنتال سبلاي", barcode: "600100002" },
    { name: "قفازات طبية", category: "material", quantity: 200, minQuantity: 50, unitPrice: "2", supplier: "الشركة الطبية", barcode: "600100003" },
    { name: "إبر تخدير", category: "tool", quantity: 5, minQuantity: 20, unitPrice: "5", supplier: "دنتال سبلاي", barcode: "600100004" },
    { name: "مضاد حيوي", category: "medicine", quantity: 60, minQuantity: 15, unitPrice: "40", supplier: "فارما", barcode: "600100005" },
  ]);

  // --- Transactions (expenses/income) ---
  await db.insert(transactions).values([
    { type: "expense", category: "إيجار", amount: "8000", description: "إيجار العيادة الشهري" },
    { type: "expense", category: "مرتبات", amount: "45000", description: "رواتب الفريق" },
    { type: "expense", category: "مستلزمات", amount: "6000", description: "شراء خامات" },
    { type: "income", category: "أخرى", amount: "2000", description: "إيراد إضافي" },
  ]);

  // --- Settings ---
  await db.insert(settings).values([
    { key: "clinic_name", value: "Dental Clinic Pro" },
    { key: "clinic_phone", value: "01284855036" },
    { key: "clinic_address", value: "القاهرة، مصر" },
    { key: "currency", value: "EGP" },
    { key: "tax_rate", value: "14" },
    { key: "language", value: "ar" },
  ]);

  // --- Demo license (pre-activated for convenience) ---
  const serial = generateSerial();
  await db.insert(licenses).values({
    serialKey: serial,
    isActivated: false,
  });
}
